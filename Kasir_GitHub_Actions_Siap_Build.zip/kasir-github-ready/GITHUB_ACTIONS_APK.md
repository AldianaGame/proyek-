# Build APK gratis dengan GitHub Actions

Project ini sengaja memakai Gradle dari runner GitHub, bukan `./gradlew`, sehingga tidak gagal karena file `gradlew` tidak ada.

## Upload
Upload **isi folder project** ke root repository GitHub, bukan folder pembungkus tambahan.

Root harus berisi:
- `app/`
- `gradle/`
- `build.gradle.kts`
- `settings.gradle.kts`
- `.github/workflows/build-apk.yml`

## Build
1. Buka tab **Actions**.
2. Pilih **Build Kasir APK**.
3. Klik **Run workflow**.
4. Tunggu sampai job hijau.
5. Buka hasil job.
6. Download artifact **kasir-nusantara-debug-apk**.
7. Extract ZIP artifact dan install file `.apk` di Android.

Repository boleh tetap **Private**.
