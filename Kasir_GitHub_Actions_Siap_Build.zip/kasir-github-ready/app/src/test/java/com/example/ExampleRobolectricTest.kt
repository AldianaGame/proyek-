package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.core.app.ApplicationProvider
import com.example.data.ProductEntity
import com.example.ui.components.CsvExportHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("KasirPro POS", appName)
    }

    @Test
    fun `login as owner and navigate across POS, Inventory, and CSV Export`() {
        composeTestRule.waitForIdle()

        // 1. Verify Login Screen is displayed
        composeTestRule.onNodeWithTag("login_screen").assertIsDisplayed()

        // 2. Toggle Dark Mode on Login Screen
        composeTestRule.onNodeWithTag("login_dark_mode_toggle").performClick()
        composeTestRule.waitForIdle()

        // 3. Quick Login as Owner (PIN 1234)
        composeTestRule.onNodeWithTag("quick_login_owner_button")
            .performScrollTo()
            .performClick()
        composeTestRule.waitForIdle()

        // 4. Verify Dashboard Screen and Top Bar are displayed
        composeTestRule.onNodeWithTag("dashboard_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("top_bar_csv_export_button").assertIsDisplayed()

        // 5. Switch to Kasir POS tab and verify 1-line list and Barcode Scanner button
        composeTestRule.onNodeWithTag("nav_tab_cashier").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("pos_cashier_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("open_barcode_scanner_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("pos_printer_settings_button").assertIsDisplayed()

        // 6. Open CSV Export Dialog from top bar
        composeTestRule.onNodeWithTag("top_bar_csv_export_button").performClick()
        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("csv_export_dialog").assertIsDisplayed()
    }

    @Test
    fun `csv export helper formats inventory products accurately`() {
        val sampleProducts = listOf(
            ProductEntity(
                id = 1,
                sku = "KOP-001",
                name = "Es Kopi Susu, Gula Aren",
                category = "Kopi Signature",
                buyPrice = 9500,
                sellPrice = 22000,
                stock = 20,
                minStockAlert = 5,
                unit = "Cup"
            )
        )
        val csv = CsvExportHelper.buildInventoryCsv(sampleProducts)
        assertTrue(csv.contains("SKU,Nama_Barang,Kategori"))
        assertTrue(csv.contains("\"Es Kopi Susu, Gula Aren\""))
        assertTrue(csv.contains("KOP-001"))
    }
}
