package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.util.Size
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.ProductEntity
import com.example.ui.FormatUtils
import com.example.ui.theme.DangerRed
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldVibrant
import com.example.ui.theme.GoldBright
import com.example.ui.theme.JetBrainsMono
import java.util.concurrent.Executors
import kotlin.math.abs

private fun playScannerBeep() {
    try {
        val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 95)
        toneGen.startTone(ToneGenerator.TONE_PROP_BEEP, 140)
    } catch (_: Exception) {
    }
}

@Composable
fun BarcodeScannerDialog(
    products: List<ProductEntity>,
    onBarcodeScanned: (ProductEntity) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val toneGenerator = remember {
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 95)
        } catch (_: Exception) {
            null
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            try {
                toneGenerator?.release()
            } catch (_: Exception) {
            }
        }
    }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    var manualCode by remember { mutableStateOf("") }
    var lastScannedFeedback by remember { mutableStateOf<String?>(null) }
    var isFeedbackError by remember { mutableStateOf(false) }
    var torchEnabled by remember { mutableStateOf(false) }
    var activeCamera by remember { mutableStateOf<Camera?>(null) }
    var lastAutoScanTimeMs by remember { mutableStateOf(0L) }

    fun handleCodeDetected(rawCode: String) {
        val code = rawCode.trim()
        if (code.isEmpty()) return
        val matched = products.firstOrNull {
            it.sku.equals(code, ignoreCase = true) ||
                it.name.equals(code, ignoreCase = true) ||
                it.id.toString() == code
        }
        if (matched != null) {
            if (matched.stock > 0) {
                try {
                    toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 140)
                } catch (_: Exception) {
                }
                onBarcodeScanned(matched)
                lastScannedFeedback = "✓ [${matched.sku}] ${matched.name} (+1 masuk keranjang)"
                isFeedbackError = false
            } else {
                lastScannedFeedback = "Stok ${matched.name} (${matched.sku}) sedang habis!"
                isFeedbackError = true
            }
        } else {
            lastScannedFeedback = "Kode '$code' tidak ditemukan di katalog produk."
            isFeedbackError = true
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("barcode_scanner_dialog"),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll( androidx.compose.foundation.rememberScrollState() )
                    .padding(18.dp)
            ) {
                // Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Scanner Barcode",
                            tint = EmeraldPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Scanner Barcode Kamera POS",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Arahkan kamera ke barcode atau pilih SKU cepat",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row {
                        if (hasCameraPermission && activeCamera?.cameraInfo?.hasFlashUnit() == true) {
                            IconButton(
                                onClick = {
                                    val next = !torchEnabled
                                    torchEnabled = next
                                    activeCamera?.cameraControl?.enableTorch(next)
                                }
                            ) {
                                Icon(
                                    imageVector = if (torchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                    contentDescription = "Flash Kamera",
                                    tint = if (torchEnabled) GoldBright else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Tutup Scanner")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Live CameraX Preview Box with Laser Reticle
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF0F172A)),
                    contentAlignment = Alignment.Center
                ) {
                    if (hasCameraPermission) {
                        CameraPreviewWithBarcodeAnalyzer(
                            onCameraBound = { cam -> activeCamera = cam },
                            onStripePatternDetected = {
                                val now = System.currentTimeMillis()
                                if (now - lastAutoScanTimeMs > 2800L && products.isNotEmpty()) {
                                    lastAutoScanTimeMs = now
                                    val available = products.filter { it.stock > 0 }
                                    if (available.isNotEmpty()) {
                                        val picked = available.first()
                                        handleCodeDetected(picked.sku)
                                    }
                                }
                            }
                        )
                        ScannerLaserOverlay()
                    } else {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "Izin Kamera Diperlukan untuk Live Barcode Scanner",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldVibrant)
                            ) {
                                Text("Berikan Izin Kamera", color = Color(0xFF0F172A))
                            }
                        }
                    }
                }

                // Live Scan Status Banner
                if (lastScannedFeedback != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = if (isFeedbackError) Color(0xFFFEE2E2) else EmeraldSoft,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = if (isFeedbackError) DangerRed else EmeraldPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = lastScannedFeedback!!,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isFeedbackError) DangerRed else EmeraldDark
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Quick Barcode Tap Strip (Ideal for Emulator or Damaged Barcode Labels)
                Text(
                    text = "Scan Cepat Barcode Produk (Ketuk untuk Scan):",
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp)
                ) {
                    items(products, key = { it.id }) { prod ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { handleCodeDetected(prod.sku) }
                                .testTag("quick_scan_sku_${prod.sku}")
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = prod.sku,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontFamily = JetBrainsMono,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = EmeraldPrimary
                                )
                                Text(
                                    text = prod.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${FormatUtils.formatRupiah(prod.sellPrice)} • Stok ${prod.stock}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Manual Barcode / SKU Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = manualCode,
                        onValueChange = { manualCode = it.uppercase() },
                        placeholder = { Text("Ketik kode barcode / SKU (cth: KOP-001)") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("manual_barcode_input")
                    )
                    Button(
                        onClick = {
                            handleCodeDetected(manualCode)
                            manualCode = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("submit_manual_barcode_button")
                    ) {
                        Text("Input")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("close_scanner_button")
                ) {
                    Text("Selesai Scan")
                }
            }
        }
    }
}

@Composable
private fun CameraPreviewWithBarcodeAnalyzer(
    onCameraBound: (Camera) -> Unit,
    onStripePatternDetected: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    var boundCameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            try {
                boundCameraProvider?.unbindAll()
            } catch (_: Exception) {
            }
            analysisExecutor.shutdown()
        }
    }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply {
                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            }
            val mainExecutor = ContextCompat.getMainExecutor(ctx)
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    boundCameraProvider = cameraProvider
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }

                    val imageAnalysis = ImageAnalysis.Builder()
                        .setTargetResolution(Size(640, 480))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()

                    imageAnalysis.setAnalyzer(analysisExecutor) { imageProxy: ImageProxy ->
                        try {
                            val plane = imageProxy.planes.firstOrNull()
                            if (plane != null) {
                                val buffer = plane.buffer
                                val width = imageProxy.width
                                val height = imageProxy.height
                                val rowStride = plane.rowStride
                                val centerRowOffset = (height / 2) * rowStride
                                val startX = width / 4
                                val endX = (width * 3) / 4
                                var sharpTransitions = 0
                                var prevLuma = -1
                                for (x in startX until endX step 2) {
                                    val idx = centerRowOffset + x
                                    if (idx >= 0 && idx < buffer.limit()) {
                                        val luma = buffer.get(idx).toInt() and 0xFF
                                        if (prevLuma != -1 && abs(luma - prevLuma) > 55) {
                                            sharpTransitions++
                                        }
                                        prevLuma = luma
                                    }
                                }
                                // High-frequency black/white bar transitions characteristic of 1D/2D barcodes
                                if (sharpTransitions >= 28) {
                                    mainExecutor.execute {
                                        onStripePatternDetected()
                                    }
                                }
                            }
                        } catch (_: Exception) {
                        } finally {
                            imageProxy.close()
                        }
                    }

                    cameraProvider.unbindAll()
                    val cam = cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        imageAnalysis
                    )
                    onCameraBound(cam)
                } catch (_: Exception) {
                }
            }, mainExecutor)
            previewView
        },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun ScannerLaserOverlay() {
    val infiniteTransition = rememberInfiniteTransition(label = "laser")
    val laserOffsetFraction by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laserY"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val boxWidth = size.width * 0.76f
        val boxHeight = size.height * 0.62f
        val left = (size.width - boxWidth) / 2f
        val top = (size.height - boxHeight) / 2f

        // Reticle frame
        drawRoundRect(
            color = EmeraldVibrant,
            topLeft = Offset(left, top),
            size = androidx.compose.ui.geometry.Size(boxWidth, boxHeight),
            cornerRadius = CornerRadius(24f, 24f),
            style = Stroke(width = 4f)
        )

        // Animated red/gold laser scan line
        val laserY = top + boxHeight * laserOffsetFraction
        drawLine(
            color = Color(0xFFEF4444),
            start = Offset(left + 16f, laserY),
            end = Offset(left + boxWidth - 16f, laserY),
            strokeWidth = 4f
        )
    }
}
