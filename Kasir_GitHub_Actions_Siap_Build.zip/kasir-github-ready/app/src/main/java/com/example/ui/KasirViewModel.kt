package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ExpenseEntity
import com.example.data.KasirRepository
import com.example.data.ProductEntity
import com.example.data.StoreProfileEntity
import com.example.data.TransactionEntity
import com.example.data.TransactionItemEntity
import com.example.data.TransactionWithItems
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class DashboardPeriod(val label: String) {
    TODAY("Hari Ini"),
    DAYS_7("7 Hari"),
    DAYS_30("30 Hari"),
    ALL("Semua")
}

data class CartItem(
    val product: ProductEntity,
    val quantity: Int
) {
    val subtotal: Long get() = product.sellPrice * quantity
    val totalCost: Long get() = product.buyPrice * quantity
}

data class DailyTrendPoint(
    val dayLabel: String,
    val dateLabel: String,
    val revenue: Long,
    val grossProfit: Long,
    val txCount: Int
)

data class CategoryStat(
    val category: String,
    val revenue: Long,
    val itemsSold: Int,
    val percentage: Float
)

data class PaymentMethodStat(
    val method: String,
    val totalAmount: Long,
    val count: Int,
    val percentage: Float
)

data class TopProductStat(
    val productId: Long,
    val productName: String,
    val sku: String,
    val category: String,
    val quantitySold: Int,
    val revenue: Long,
    val profit: Long,
    val currentStock: Int
)

data class DashboardAnalytics(
    val period: DashboardPeriod = DashboardPeriod.DAYS_7,
    val grossRevenue: Long = 0L,
    val totalCogs: Long = 0L, // Total HPP
    val grossProfit: Long = 0L,
    val totalExpenses: Long = 0L,
    val netProfit: Long = 0L,
    val profitMarginPercent: Float = 0f,
    val completedTxCount: Int = 0,
    val voidTxCount: Int = 0,
    val totalItemsSold: Int = 0,
    val averageOrderValue: Long = 0L,
    val todayRevenue: Long = 0L,
    val dailyTarget: Long = 3500000L,
    val dailyTargetProgress: Float = 0f,
    val dailyTrend: List<DailyTrendPoint> = emptyList(),
    val categoryStats: List<CategoryStat> = emptyList(),
    val paymentStats: List<PaymentMethodStat> = emptyList(),
    val topProducts: List<TopProductStat> = emptyList(),
    val lowStockProducts: List<ProductEntity> = emptyList(),
    val totalInventoryAssetCost: Long = 0L,
    val totalInventoryRetailValue: Long = 0L,
    val totalSkuCount: Int = 0
)

class KasirViewModel(private val repository: KasirRepository) : ViewModel() {

    val products: StateFlow<List<ProductEntity>> = repository.activeProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<TransactionWithItems>> = repository.transactionsWithItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val expenses: StateFlow<List<ExpenseEntity>> = repository.expenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val storeProfile: StateFlow<StoreProfileEntity> = repository.storeProfile
        .combine(MutableStateFlow(StoreProfileEntity())) { dbProfile, defaultProfile ->
            dbProfile ?: defaultProfile
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreProfileEntity())

    private val _selectedPeriod = MutableStateFlow(DashboardPeriod.DAYS_7)
    val selectedPeriod: StateFlow<DashboardPeriod> = _selectedPeriod.asStateFlow()

    // POS Cart State
    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _discountAmount = MutableStateFlow(0L)
    val discountAmount: StateFlow<Long> = _discountAmount.asStateFlow()

    private val _taxEnabled = MutableStateFlow(true)
    val taxEnabled: StateFlow<Boolean> = _taxEnabled.asStateFlow()

    private val _lastCompletedSale = MutableStateFlow<TransactionWithItems?>(null)
    val lastCompletedSale: StateFlow<TransactionWithItems?> = _lastCompletedSale.asStateFlow()

    val dashboardAnalytics: StateFlow<DashboardAnalytics> = combine(
        products,
        transactions,
        expenses,
        storeProfile,
        _selectedPeriod
    ) { prodList, txList, expList, profile, period ->
        computeAnalytics(prodList, txList, expList, profile, period)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardAnalytics())

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
        // Keep cart items synchronized with latest product details & stock limits
        viewModelScope.launch {
            products.collect { latestProducts ->
                if (latestProducts.isNotEmpty()) {
                    val map = latestProducts.associateBy { it.id }
                    _cart.update { currentCart ->
                        currentCart.mapNotNull { item ->
                            val latest = map[item.product.id]
                            if (latest == null || !latest.isActive || latest.stock <= 0) {
                                null
                            } else {
                                item.copy(
                                    product = latest,
                                    quantity = item.quantity.coerceAtMost(latest.stock)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    fun selectPeriod(period: DashboardPeriod) {
        _selectedPeriod.value = period
    }

    // --- CART & CHECKOUT ACTIONS ---
    fun addToCart(product: ProductEntity) {
        val latestProduct = products.value.find { it.id == product.id } ?: product
        if (latestProduct.stock <= 0) return
        _cart.update { current ->
            val existing = current.find { it.product.id == latestProduct.id }
            if (existing != null) {
                if (existing.quantity < latestProduct.stock) {
                    current.map {
                        if (it.product.id == latestProduct.id) {
                            it.copy(product = latestProduct, quantity = it.quantity + 1)
                        } else it
                    }
                } else {
                    current
                }
            } else {
                current + CartItem(product = latestProduct, quantity = 1)
            }
        }
    }

    fun updateCartQuantity(productId: Long, delta: Int) {
        val latestStock = products.value.find { it.id == productId }?.stock
        _cart.update { current ->
            current.mapNotNull { item ->
                if (item.product.id == productId) {
                    val maxStock = latestStock ?: item.product.stock
                    val newQty = (item.quantity + delta).coerceAtMost(maxStock)
                    if (newQty <= 0) null else item.copy(quantity = newQty)
                } else {
                    item
                }
            }
        }
    }

    fun setDiscountAmount(discount: Long) {
        _discountAmount.value = discount.coerceAtLeast(0L)
    }

    fun setTaxEnabled(enabled: Boolean) {
        _taxEnabled.value = enabled
    }

    fun clearCart() {
        _cart.value = emptyList()
        _discountAmount.value = 0L
    }

    fun dismissReceiptModal() {
        _lastCompletedSale.value = null
    }

    fun processCheckout(
        customerName: String,
        paymentMethod: String,
        amountPaid: Long,
        notes: String
    ) {
        val currentCart = _cart.value
        if (currentCart.isEmpty()) return

        val profile = storeProfile.value
        val subtotal = currentCart.sumOf { it.subtotal }
        val totalCost = currentCart.sumOf { it.totalCost }
        val discount = _discountAmount.value.coerceAtMost(subtotal)
        val taxableAmount = (subtotal - discount).coerceAtLeast(0L)
        val tax = if (_taxEnabled.value) (taxableAmount * profile.taxPercent) / 100L else 0L
        val totalAmount = taxableAmount + tax
        val actualPaid = if (paymentMethod == "TUNAI") amountPaid.coerceAtLeast(totalAmount) else totalAmount
        val change = (actualPaid - totalAmount).coerceAtLeast(0L)

        val now = System.currentTimeMillis()
        val sdf = SimpleDateFormat("yyMMdd-HHmmss", Locale.US)
        val invoiceNumber = "INV-${sdf.format(Date(now))}"

        val txEntity = TransactionEntity(
            invoiceNumber = invoiceNumber,
            timestamp = now,
            customerName = customerName.trim().ifEmpty { "Pelanggan Umum" },
            subtotal = subtotal,
            discountAmount = discount,
            taxAmount = tax,
            totalAmount = totalAmount,
            totalCost = totalCost,
            paymentMethod = paymentMethod,
            amountPaid = actualPaid,
            changeAmount = change,
            cashierName = profile.cashierName,
            notes = notes.trim(),
            status = "COMPLETED"
        )

        val txItems = currentCart.map { item ->
            TransactionItemEntity(
                transactionId = 0L,
                productId = item.product.id,
                productName = item.product.name,
                sku = item.product.sku,
                category = item.product.category,
                buyPrice = item.product.buyPrice,
                sellPrice = item.product.sellPrice,
                quantity = item.quantity,
                subtotal = item.subtotal
            )
        }

        viewModelScope.launch {
            val insertedId = repository.recordSale(txEntity, txItems)
            _lastCompletedSale.value = TransactionWithItems(
                transaction = txEntity.copy(id = insertedId),
                items = txItems.map { it.copy(transactionId = insertedId) }
            )
            clearCart()
        }
    }

    // --- PRODUCT & INVENTORY ACTIONS ---
    fun saveProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.saveProduct(product)
        }
    }

    fun deleteProduct(productId: Long) {
        viewModelScope.launch {
            repository.deleteProduct(productId)
            _cart.update { list -> list.filterNot { it.product.id == productId } }
        }
    }

    fun adjustProductStock(productId: Long, delta: Int) {
        viewModelScope.launch {
            repository.adjustStock(productId, delta)
        }
    }

    // --- TRANSACTION & EXPENSE ACTIONS ---
    fun voidTransaction(txWithItems: TransactionWithItems) {
        viewModelScope.launch {
            repository.voidTransaction(txWithItems)
            if (_lastCompletedSale.value?.transaction?.id == txWithItems.transaction.id) {
                _lastCompletedSale.value = null
            }
        }
    }

    fun addExpense(title: String, category: String, amount: Long, notes: String) {
        if (title.isBlank() || amount <= 0L) return
        viewModelScope.launch {
            repository.addExpense(
                ExpenseEntity(
                    title = title.trim(),
                    category = category,
                    amount = amount,
                    timestamp = System.currentTimeMillis(),
                    notes = notes.trim()
                )
            )
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.deleteExpense(expense)
        }
    }

    fun updateStoreProfile(profile: StoreProfileEntity) {
        viewModelScope.launch {
            repository.saveStoreProfile(profile)
        }
    }

    private fun computeAnalytics(
        products: List<ProductEntity>,
        allTx: List<TransactionWithItems>,
        allExpenses: List<ExpenseEntity>,
        profile: StoreProfileEntity,
        period: DashboardPeriod
    ): DashboardAnalytics {
        val now = System.currentTimeMillis()
        val startOfToday = FormatUtils.getStartOfTodayMs(now)
        val dayMs = 24 * 3600_000L

        val cutoffMs = when (period) {
            DashboardPeriod.TODAY -> startOfToday
            DashboardPeriod.DAYS_7 -> startOfToday - 6 * dayMs
            DashboardPeriod.DAYS_30 -> startOfToday - 29 * dayMs
            DashboardPeriod.ALL -> 0L
        }

        val filteredTx = allTx.filter { it.transaction.timestamp >= cutoffMs }
        val completedTx = filteredTx.filter { it.transaction.status == "COMPLETED" }
        val voidTxCount = filteredTx.count { it.transaction.status == "VOID" }
        val filteredExpenses = allExpenses.filter { it.timestamp >= cutoffMs }

        val grossRevenue = completedTx.sumOf { it.transaction.totalAmount }
        val totalCogs = completedTx.sumOf { it.transaction.totalCost }
        val grossProfit = grossRevenue - totalCogs
        val totalExpenses = filteredExpenses.sumOf { it.amount }
        val netProfit = grossProfit - totalExpenses
        val profitMarginPercent = if (grossRevenue > 0) {
            ((netProfit.toDouble() / grossRevenue.toDouble()) * 100.0).toFloat()
        } else 0f

        val completedTxCount = completedTx.size
        val totalItemsSold = completedTx.sumOf { tx -> tx.items.sumOf { it.quantity } }
        val avgOrderValue = if (completedTxCount > 0) grossRevenue / completedTxCount else 0L

        // Today's revenue vs daily target
        val todayCompletedTx = allTx.filter {
            it.transaction.status == "COMPLETED" && it.transaction.timestamp >= startOfToday
        }
        val todayRevenue = todayCompletedTx.sumOf { it.transaction.totalAmount }
        val target = profile.dailyTarget.coerceAtLeast(1L)
        val targetProgress = (todayRevenue.toFloat() / target.toFloat()).coerceIn(0f, 1.5f)

        // 7-Day Daily Trend (always 7 days for the chart so it's informative)
        val dailyTrend = (6 downTo 0).map { daysAgo ->
            val dayStart = startOfToday - daysAgo * dayMs
            val dayEnd = dayStart + dayMs
            val daySales = allTx.filter {
                it.transaction.status == "COMPLETED" &&
                    it.transaction.timestamp in dayStart until dayEnd
            }
            val rev = daySales.sumOf { it.transaction.totalAmount }
            val cost = daySales.sumOf { it.transaction.totalCost }
            DailyTrendPoint(
                dayLabel = if (daysAgo == 0) "Hari Ini" else FormatUtils.formatDayLabel(dayStart),
                dateLabel = FormatUtils.formatShortDate(dayStart),
                revenue = rev,
                grossProfit = rev - cost,
                txCount = daySales.size
            )
        }

        // Category Breakdown
        val allSoldItems = completedTx.flatMap { it.items }
        val totalItemRevenue = allSoldItems.sumOf { it.subtotal }.coerceAtLeast(1L)
        val categoryStats = allSoldItems
            .groupBy { it.category }
            .map { (cat, items) ->
                val catRev = items.sumOf { it.subtotal }
                val catQty = items.sumOf { it.quantity }
                CategoryStat(
                    category = cat,
                    revenue = catRev,
                    itemsSold = catQty,
                    percentage = (catRev.toFloat() / totalItemRevenue.toFloat()) * 100f
                )
            }
            .sortedByDescending { it.revenue }

        // Payment Method Breakdown
        val totalPaymentRev = grossRevenue.coerceAtLeast(1L)
        val paymentStats = completedTx
            .groupBy { it.transaction.paymentMethod }
            .map { (method, list) ->
                val sum = list.sumOf { it.transaction.totalAmount }
                PaymentMethodStat(
                    method = method,
                    totalAmount = sum,
                    count = list.size,
                    percentage = (sum.toFloat() / totalPaymentRev.toFloat()) * 100f
                )
            }
            .sortedByDescending { it.totalAmount }

        // Top Selling Products Leaderboard
        val productStockMap = products.associateBy { it.id }
        val topProducts = allSoldItems
            .groupBy { it.productId }
            .map { (prodId, items) ->
                val first = items.first()
                val qty = items.sumOf { it.quantity }
                val rev = items.sumOf { it.subtotal }
                val cost = items.sumOf { it.buyPrice * it.quantity }
                TopProductStat(
                    productId = prodId,
                    productName = first.productName,
                    sku = first.sku,
                    category = first.category,
                    quantitySold = qty,
                    revenue = rev,
                    profit = rev - cost,
                    currentStock = productStockMap[prodId]?.stock ?: 0
                )
            }
            .sortedByDescending { it.quantitySold }
            .take(6)

        val lowStockProducts = products
            .filter { it.stock <= it.minStockAlert }
            .sortedBy { it.stock }

        val totalInventoryAssetCost = products.sumOf { it.buyPrice * it.stock.coerceAtLeast(0) }
        val totalInventoryRetailValue = products.sumOf { it.sellPrice * it.stock.coerceAtLeast(0) }

        return DashboardAnalytics(
            period = period,
            grossRevenue = grossRevenue,
            totalCogs = totalCogs,
            grossProfit = grossProfit,
            totalExpenses = totalExpenses,
            netProfit = netProfit,
            profitMarginPercent = profitMarginPercent,
            completedTxCount = completedTxCount,
            voidTxCount = voidTxCount,
            totalItemsSold = totalItemsSold,
            averageOrderValue = avgOrderValue,
            todayRevenue = todayRevenue,
            dailyTarget = profile.dailyTarget,
            dailyTargetProgress = targetProgress,
            dailyTrend = dailyTrend,
            categoryStats = categoryStats,
            paymentStats = paymentStats,
            topProducts = topProducts,
            lowStockProducts = lowStockProducts,
            totalInventoryAssetCost = totalInventoryAssetCost,
            totalInventoryRetailValue = totalInventoryRetailValue,
            totalSkuCount = products.size
        )
    }

    companion object {
        fun provideFactory(repository: KasirRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return KasirViewModel(repository) as T
                }
            }
    }
}
