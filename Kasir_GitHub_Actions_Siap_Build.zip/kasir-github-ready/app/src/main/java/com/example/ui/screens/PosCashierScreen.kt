package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCartCheckout
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ProductEntity
import com.example.data.StoreProfileEntity
import com.example.ui.CartItem
import com.example.ui.FormatUtils
import com.example.ui.components.BarcodeScannerDialog
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerSoft
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.JetBrainsMono

@Composable
fun PosCashierScreen(
    products: List<ProductEntity>,
    cart: List<CartItem>,
    discountAmount: Long,
    taxEnabled: Boolean,
    storeProfile: StoreProfileEntity,
    onAddToCart: (ProductEntity) -> Unit,
    onUpdateCartQty: (Long, Int) -> Unit,
    onClearCart: () -> Unit,
    onSetDiscount: (Long) -> Unit,
    onSetTaxEnabled: (Boolean) -> Unit,
    onOpenPrinterSettings: () -> Unit,
    onCheckout: (customerName: String, paymentMethod: String, amountPaid: Long, notes: String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Semua") }
    var showCheckoutModal by remember { mutableStateOf(false) }
    var showBarcodeScanner by remember { mutableStateOf(false) }

    val categories by remember(products) {
        derivedStateOf {
            listOf("Semua") + products.map { it.category }.distinct()
        }
    }

    val filteredProducts by remember(products, searchQuery, selectedCategory) {
        derivedStateOf {
            products.filter { p ->
                val matchesCat = selectedCategory == "Semua" || p.category == selectedCategory
                val q = searchQuery.trim().lowercase()
                val matchesQuery = q.isEmpty() ||
                    p.name.lowercase().contains(q) ||
                    p.sku.lowercase().contains(q) ||
                    p.category.lowercase().contains(q)
                matchesCat && matchesQuery
            }
        }
    }

    val cartQtyMap by remember(cart) {
        derivedStateOf { cart.associate { it.product.id to it.quantity } }
    }

    val totalCartItems = cart.sumOf { it.quantity }
    val subtotal = cart.sumOf { it.subtotal }
    val effectiveDiscount = discountAmount.coerceAtMost(subtotal)
    val taxable = (subtotal - effectiveDiscount).coerceAtLeast(0L)
    val taxAmount = if (taxEnabled) (taxable * storeProfile.taxPercent) / 100L else 0L
    val grandTotal = taxable + taxAmount

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("pos_cashier_screen")
    ) {
        // Top Header with Printer & Barcode Scanner Controls
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Kasir POS",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Tema 1 Baris: Nama • Harga • Stok",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Printer Settings Button
                        OutlinedButton(
                            onClick = onOpenPrinterSettings,
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("pos_printer_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Print,
                                contentDescription = "Sistem Printer",
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Printer", style = MaterialTheme.typography.labelSmall)
                        }

                        // Camera Barcode Scanner Button
                        Button(
                            onClick = { showBarcodeScanner = true },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("open_barcode_scanner_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = "Scan Barcode Kamera",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Scan Barcode", style = MaterialTheme.typography.labelSmall)
                        }

                        if (cart.isNotEmpty()) {
                            IconButton(
                                onClick = onClearCart,
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("clear_cart_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteSweep,
                                    contentDescription = "Kosongkan Keranjang",
                                    tint = DangerRed
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Search Bar with Quick Barcode Icon
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Cari nama barang atau scan barcode...") },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Cari Produk")
                    },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Hapus Pencarian")
                                }
                            }
                            IconButton(
                                onClick = { showBarcodeScanner = true },
                                modifier = Modifier.testTag("search_bar_scanner_icon")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = "Buka Kamera Scanner",
                                    tint = EmeraldPrimary
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pos_search_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { category ->
                        val isSelected = category == selectedCategory
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCategory = category },
                            label = { Text(category) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // 1-Line Table Column Header (Nama Barang | Harga Barang | Stok Barang)
        Surface(
            color = EmeraldDark,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "NAMA BARANG",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = EmeraldSoft,
                    modifier = Modifier.weight(1.45f)
                )
                Text(
                    text = "HARGA BARANG",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = GoldBright,
                    textAlign = TextAlign.End,
                    modifier = Modifier.weight(0.95f)
                )
                Text(
                    text = "STOK BARANG",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = EmeraldSoft,
                    textAlign = TextAlign.End,
                    modifier = Modifier.weight(0.85f)
                )
            }
        }

        // 1-Row Product List (Only Nama Barang, Harga Barang, Stok Barang in 1 line)
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("pos_single_line_list"),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredProducts, key = { it.id }) { product ->
                val qtyInCart = cartQtyMap[product.id] ?: 0
                PosProductSingleLineRow(
                    product = product,
                    qtyInCart = qtyInCart,
                    onAdd = { onAddToCart(product) },
                    onDecrement = { onUpdateCartQty(product.id, -1) }
                )
            }
        }

        // Sticky Bottom Cart Checkout Bar
        AnimatedVisibility(visible = cart.isNotEmpty()) {
            Surface(
                color = EmeraldDark,
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                shadowElevation = 12.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = GoldBright,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = "$totalCartItems Item",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF0F172A),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (taxEnabled) "Termasuk PPN ${storeProfile.taxPercent}%" else "Tanpa PPN",
                                style = MaterialTheme.typography.bodySmall,
                                color = EmeraldSoft
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = FormatUtils.formatRupiah(grandTotal),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = JetBrainsMono,
                                fontWeight = FontWeight.Bold
                            ),
                            color = Color.White
                        )
                    }

                    Button(
                        onClick = { showCheckoutModal = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldBright,
                            contentColor = Color(0xFF0F172A)
                        ),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                        modifier = Modifier.testTag("open_checkout_modal_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCartCheckout,
                            contentDescription = "Bayar Sekarang"
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Bayar",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }

    if (showBarcodeScanner) {
        BarcodeScannerDialog(
            products = products,
            onBarcodeScanned = { scannedProduct ->
                onAddToCart(scannedProduct)
            },
            onDismiss = { showBarcodeScanner = false }
        )
    }

    if (showCheckoutModal) {
        PosCheckoutDialog(
            cart = cart,
            subtotal = subtotal,
            discountAmount = effectiveDiscount,
            taxEnabled = taxEnabled,
            taxPercent = storeProfile.taxPercent,
            taxAmount = taxAmount,
            grandTotal = grandTotal,
            onUpdateCartQty = onUpdateCartQty,
            onSetDiscount = onSetDiscount,
            onSetTaxEnabled = onSetTaxEnabled,
            onDismiss = { showCheckoutModal = false },
            onConfirmPayment = { customerName, paymentMethod, amountPaid, notes ->
                showCheckoutModal = false
                onCheckout(customerName, paymentMethod, amountPaid, notes)
            }
        )
    }
}

/**
 * Tema 1 Baris di POS Kasir:
 * Hanya menampilkan Nama Barang, Harga Barang, dan Stok Barang dalam 1 baris horizontal.
 */
@Composable
private fun PosProductSingleLineRow(
    product: ProductEntity,
    qtyInCart: Int,
    onAdd: () -> Unit,
    onDecrement: () -> Unit
) {
    val isOutOfStock = product.stock <= 0
    val isLowStock = product.stock in 1..product.minStockAlert

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (qtyInCart > 0) {
                    Modifier.border(1.5.dp, EmeraldPrimary, RoundedCornerShape(14.dp))
                } else {
                    Modifier
                }
            )
            .clickable(enabled = !isOutOfStock) { onAdd() }
            .testTag("pos_product_card_${product.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (qtyInCart > 0) {
                EmeraldSoft.copy(alpha = 0.28f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. NAMA BARANG (1 Baris)
            Row(
                modifier = Modifier.weight(1.45f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (qtyInCart > 0) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(EmeraldPrimary)
                            .clickable { onDecrement() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$qtyInCart",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // 2. HARGA BARANG (1 Baris)
            Text(
                text = FormatUtils.formatRupiah(product.sellPrice),
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = JetBrainsMono,
                    fontWeight = FontWeight.Bold
                ),
                color = EmeraldPrimary,
                maxLines = 1,
                textAlign = TextAlign.End,
                modifier = Modifier
                    .weight(0.95f)
                    .padding(horizontal = 4.dp)
            )

            // 3. STOK BARANG (1 Baris)
            Box(
                modifier = Modifier.weight(0.85f),
                contentAlignment = Alignment.CenterEnd
            ) {
                Surface(
                    color = when {
                        isOutOfStock -> DangerSoft
                        isLowStock -> GoldSoft
                        else -> EmeraldSoft
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (isOutOfStock) "Habis (0)" else "Stok: ${product.stock}",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = when {
                            isOutOfStock -> DangerRed
                            isLowStock -> GoldAccent
                            else -> EmeraldPrimary
                        },
                        maxLines = 1,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun PosCheckoutDialog(
    cart: List<CartItem>,
    subtotal: Long,
    discountAmount: Long,
    taxEnabled: Boolean,
    taxPercent: Int,
    taxAmount: Long,
    grandTotal: Long,
    onUpdateCartQty: (Long, Int) -> Unit,
    onSetDiscount: (Long) -> Unit,
    onSetTaxEnabled: (Boolean) -> Unit,
    onDismiss: () -> Unit,
    onConfirmPayment: (customerName: String, paymentMethod: String, amountPaid: Long, notes: String) -> Unit
) {
    var customerName by remember { mutableStateOf("") }
    var selectedMethod by remember { mutableStateOf("TUNAI") }
    var cashPaidText by remember(grandTotal) { mutableStateOf(grandTotal.toString()) }
    var notes by remember { mutableStateOf("") }

    androidx.compose.runtime.LaunchedEffect(cart.isEmpty()) {
        if (cart.isEmpty()) {
            onDismiss()
        }
    }

    val cashPaid = cashPaidText.toLongOrNull() ?: grandTotal
    val changeAmount = if (selectedMethod == "TUNAI") {
        (cashPaid - grandTotal).coerceAtLeast(0L)
    } else 0L

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("pos_checkout_dialog"),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Konfirmasi & Pembayaran Kasir",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "${cart.sumOf { it.quantity }} item dalam keranjang",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                // Cart Items List
                cart.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.product.name,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "${FormatUtils.formatRupiah(item.product.sellPrice)} x ${item.quantity}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(
                                onClick = { onUpdateCartQty(item.product.id, -1) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Kurangi")
                            }
                            Text(
                                text = "${item.quantity}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            IconButton(
                                onClick = { onUpdateCartQty(item.product.id, 1) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Tambah")
                            }
                            Text(
                                text = FormatUtils.formatRupiah(item.subtotal),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                modifier = Modifier.width(88.dp),
                                textAlign = TextAlign.End
                            )
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                // Customer Name
                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text("Nama Pelanggan (Opsional)") },
                    placeholder = { Text("Pelanggan Umum") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Quick Discount Selector
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocalOffer,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Potongan Diskon / Promo",
                        style = MaterialTheme.typography.titleSmall
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val discountOptions = listOf(
                        "Tanpa Diskon" to 0L,
                        "Rp 5.000" to 5000L,
                        "Rp 10.000" to 10000L,
                        "Diskon 10%" to (subtotal * 10L) / 100L
                    )
                    items(discountOptions) { (label, amount) ->
                        FilterChip(
                            selected = discountAmount == amount,
                            onClick = { onSetDiscount(amount) },
                            label = { Text(label) }
                        )
                    }
                }

                // Tax Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Terapkan Pajak PPN ($taxPercent%)",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Switch(
                        checked = taxEnabled,
                        onCheckedChange = onSetTaxEnabled
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Payment Method Selection
                Text(
                    text = "Pilih Metode Pembayaran",
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(modifier = Modifier.height(8.dp))

                val methods = listOf(
                    "TUNAI" to Icons.Default.Payments,
                    "QRIS" to Icons.Default.QrCode2,
                    "DEBIT" to Icons.Default.CreditCard,
                    "TRANSFER" to Icons.Default.AccountBalance
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    methods.forEach { (method, icon) ->
                        val selected = selectedMethod == method
                        Surface(
                            color = if (selected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedMethod = method }
                                .testTag("payment_method_$method")
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = method,
                                    tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = method,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                if (selectedMethod == "TUNAI") {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = cashPaidText,
                        onValueChange = { cashPaidText = it.filter { c -> c.isDigit() } },
                        label = { Text("Uang Tunai Diterima (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val quickCash = listOf(
                            "Uang Pas" to grandTotal,
                            "Rp 50.000" to 50_000L,
                            "Rp 100.000" to 100_000L,
                            "Rp 150.000" to 150_000L,
                            "Rp 200.000" to 200_000L
                        )
                        items(quickCash) { (label, nom) ->
                            OutlinedButton(
                                onClick = { cashPaidText = nom.coerceAtLeast(grandTotal).toString() },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(label, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Final Calculation Box
                Surface(
                    color = EmeraldSoft.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        SummaryRow("Subtotal", FormatUtils.formatRupiah(subtotal))
                        if (discountAmount > 0) {
                            SummaryRow("Diskon Promo", "- ${FormatUtils.formatRupiah(discountAmount)}")
                        }
                        if (taxEnabled) {
                            SummaryRow("PPN ($taxPercent%)", FormatUtils.formatRupiah(taxAmount))
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "TOTAL TAGIHAN",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = FormatUtils.formatRupiah(grandTotal),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = JetBrainsMono,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = EmeraldPrimary
                            )
                        }
                        if (selectedMethod == "TUNAI") {
                            Spacer(modifier = Modifier.height(4.dp))
                            SummaryRow("Kembalian Pelanggan", FormatUtils.formatRupiah(changeAmount))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        onConfirmPayment(
                            customerName,
                            selectedMethod,
                            if (selectedMethod == "TUNAI") cashPaid.coerceAtLeast(grandTotal) else grandTotal,
                            notes
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("confirm_payment_button")
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Selesaikan Pembayaran & Cetak Struk",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall)
        Text(text = value, style = MaterialTheme.typography.labelMedium)
    }
}
