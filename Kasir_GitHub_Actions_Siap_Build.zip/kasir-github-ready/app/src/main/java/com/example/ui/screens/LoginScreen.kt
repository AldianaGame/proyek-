package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.StoreProfileEntity
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerSoft
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldVibrant
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.JetBrainsMono

enum class UserRole(val title: String, val badgeText: String, val defaultPin: String) {
    CASHIER("Kasir POS", "KASIR SHIFT", "0000"),
    OWNER("Owner / Pemilik", "OWNER PRO", "1234")
}

data class ActiveSession(
    val role: UserRole,
    val displayName: String
)

@Composable
fun LoginScreen(
    storeProfile: StoreProfileEntity,
    isDarkMode: Boolean = false,
    onToggleDarkMode: () -> Unit = {},
    onLoginSuccess: (ActiveSession) -> Unit
) {
    var selectedRole by remember { mutableStateOf(UserRole.CASHIER) }
    var pinInput by remember { mutableStateOf("") }
    var cashierName by remember(storeProfile.cashierName) {
        mutableStateOf(storeProfile.cashierName.ifBlank { "Nadia Putri (Shift Pagi)" })
    }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val shiftPresets = listOf(
        "Nadia Putri (Shift Pagi)",
        "Rizky Pratama (Shift Sore)",
        "Budi Santoso (Kasir Utama)"
    )

    fun verifyAndLogin(pinToVerify: String = pinInput) {
        val expectedPin = selectedRole.defaultPin
        if (pinToVerify == expectedPin) {
            errorMessage = null
            val activeName = if (selectedRole == UserRole.OWNER) {
                "Owner (${storeProfile.storeName})"
            } else {
                cashierName.trim().ifBlank { "Kasir Utama" }
            }
            onLoginSuccess(ActiveSession(role = selectedRole, displayName = activeName))
        } else {
            errorMessage = "PIN tidak sesuai! Gunakan PIN ${selectedRole.defaultPin} untuk ${selectedRole.title}."
            pinInput = ""
        }
    }

    fun appendDigit(digit: String) {
        if (pinInput.length < 4) {
            val next = pinInput + digit
            pinInput = next
            errorMessage = null
            if (next.length == 4) {
                verifyAndLogin(next)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("login_screen"),
        contentAlignment = Alignment.TopCenter
    ) {
        // Top Decorative Hero Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_pos_hero),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                EmeraldDark.copy(alpha = 0.88f),
                                EmeraldDark.copy(alpha = 0.96f),
                                MaterialTheme.colorScheme.background
                            )
                        )
                    )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 500.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Surface(
                    onClick = onToggleDarkMode,
                    color = Color.White.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.testTag("login_dark_mode_toggle")
                ) {
                    Text(
                        text = if (isDarkMode) "☀ Mode Terang" else "🌙 Mode Gelap",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            // Store Logo & Title
            Surface(
                color = GoldBright,
                shape = CircleShape,
                modifier = Modifier.size(46.dp),
                shadowElevation = 6.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Default.PointOfSale,
                        contentDescription = null,
                        tint = Color(0xFF0F172A),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = storeProfile.storeName,
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                textAlign = TextAlign.Center
            )
            Text(
                text = "Pilih akses Login Kasir atau Owner",
                style = MaterialTheme.typography.bodySmall,
                color = EmeraldSoft,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Main Login Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Role Selector Tabs (Kasir vs Owner)
                    Text(
                        text = "Pilih Peran Akses",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        RoleOptionCard(
                            modifier = Modifier.weight(1f),
                            role = UserRole.CASHIER,
                            subtitle = "Transaksi & Struk",
                            icon = Icons.Default.Badge,
                            isSelected = selectedRole == UserRole.CASHIER,
                            onClick = {
                                selectedRole = UserRole.CASHIER
                                pinInput = ""
                                errorMessage = null
                            }
                        )
                        RoleOptionCard(
                            modifier = Modifier.weight(1f),
                            role = UserRole.OWNER,
                            subtitle = "Dashboard & Laba",
                            icon = Icons.Default.AdminPanelSettings,
                            isSelected = selectedRole == UserRole.OWNER,
                            onClick = {
                                selectedRole = UserRole.OWNER
                                pinInput = ""
                                errorMessage = null
                            }
                        )
                    }

                    // Shift Cashier Selector (Only when Cashier is selected)
                    AnimatedVisibility(visible = selectedRole == UserRole.CASHIER) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 14.dp)
                        ) {
                            OutlinedTextField(
                                value = cashierName,
                                onValueChange = { cashierName = it },
                                label = { Text("Nama Kasir Shift Aktif") },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("login_cashier_name_input")
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(shiftPresets) { preset ->
                                    FilterChip(
                                        selected = cashierName == preset,
                                        onClick = { cashierName = preset },
                                        label = {
                                            Text(
                                                text = preset.substringBefore(" ("),
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = EmeraldSoft,
                                            selectedLabelColor = EmeraldDark
                                        )
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // PIN Dots Display
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = if (selectedRole == UserRole.OWNER) GoldAccent else EmeraldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Masukkan 4 Digit PIN ${selectedRole.title} (Default: ${selectedRole.defaultPin})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in 0 until 4) {
                            val filled = i < pinInput.length
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (filled) {
                                            if (selectedRole == UserRole.OWNER) GoldBright else EmeraldPrimary
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant
                                        }
                                    )
                                    .border(
                                        width = 1.5.dp,
                                        color = if (filled) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                                        shape = CircleShape
                                    )
                            )
                        }
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = DangerSoft,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = errorMessage!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = DangerRed,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Numeric PIN Pad (3x4 Grid)
                    val rows = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("CLR", "0", "DEL")
                    )

                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        rows.forEach { rowKeys ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                rowKeys.forEach { key ->
                                    PinPadKeyButton(
                                        modifier = Modifier.weight(1f),
                                        key = key,
                                        onClick = {
                                            when (key) {
                                                "CLR" -> {
                                                    pinInput = ""
                                                    errorMessage = null
                                                }
                                                "DEL" -> {
                                                    if (pinInput.isNotEmpty()) {
                                                        pinInput = pinInput.dropLast(1)
                                                    }
                                                }
                                                else -> appendDigit(key)
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Quick 1-Tap Login Buttons for Fast Access
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                selectedRole = UserRole.CASHIER
                                verifyAndLogin(UserRole.CASHIER.defaultPin)
                            },
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 10.dp, horizontal = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("quick_login_cashier_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Masuk Kasir (0000)",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }

                        Button(
                            onClick = {
                                selectedRole = UserRole.OWNER
                                verifyAndLogin(UserRole.OWNER.defaultPin)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GoldBright,
                                contentColor = Color(0xFF0F172A)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(vertical = 10.dp, horizontal = 8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("quick_login_owner_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Login,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Masuk Owner (1234)",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RoleOptionCard(
    modifier: Modifier = Modifier,
    role: UserRole,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val activeColor = if (role == UserRole.OWNER) GoldAccent else EmeraldPrimary
    val activeBg = if (role == UserRole.OWNER) GoldSoft.copy(alpha = 0.55f) else EmeraldSoft.copy(alpha = 0.55f)

    Surface(
        color = if (isSelected) activeBg else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .then(
                if (isSelected) Modifier.border(2.dp, activeColor, RoundedCornerShape(16.dp))
                else Modifier
            )
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("role_card_${role.name}")
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp, horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        if (isSelected) activeColor else MaterialTheme.colorScheme.surfaceVariant,
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = role.title,
                    tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = role.title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = if (isSelected) activeColor else MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PinPadKeyButton(
    modifier: Modifier = Modifier,
    key: String,
    onClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .height(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag("pin_key_$key")
    ) {
        Box(contentAlignment = Alignment.Center) {
            if (key == "DEL") {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "Hapus Digit",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            } else {
                Text(
                    text = key,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = JetBrainsMono,
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (key == "CLR") DangerRed else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
