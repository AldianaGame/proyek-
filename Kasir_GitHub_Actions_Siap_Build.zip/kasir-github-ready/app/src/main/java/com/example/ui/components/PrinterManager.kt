package com.example.ui.components

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import com.example.data.StoreProfileEntity
import com.example.data.TransactionWithItems
import com.example.ui.FormatUtils
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerSoft
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.InfoSoft
import com.example.ui.theme.JetBrainsMono
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.UUID

data class BluetoothPrinterDevice(
    val name: String,
    val address: String
)

data class PrinterConfig(
    val paperWidthMm: Int = 58, // 58 or 80
    val selectedBtName: String = "",
    val selectedBtAddress: String = "",
    val autoPrintOnCheckout: Boolean = false,
    val openCashDrawer: Boolean = true
)

object EscPosPrinterHelper {
    private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private const val PREFS_NAME = "kasir_printer_prefs"

    fun loadConfig(context: Context): PrinterConfig {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return PrinterConfig(
            paperWidthMm = prefs.getInt("paper_width_mm", 58),
            selectedBtName = prefs.getString("bt_name", "") ?: "",
            selectedBtAddress = prefs.getString("bt_address", "") ?: "",
            autoPrintOnCheckout = prefs.getBoolean("auto_print", false),
            openCashDrawer = prefs.getBoolean("open_drawer", true)
        )
    }

    fun saveConfig(context: Context, config: PrinterConfig) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().apply {
            putInt("paper_width_mm", config.paperWidthMm)
            putString("bt_name", config.selectedBtName)
            putString("bt_address", config.selectedBtAddress)
            putBoolean("auto_print", config.autoPrintOnCheckout)
            putBoolean("open_drawer", config.openCashDrawer)
            apply()
        }
    }

    fun hasBluetoothPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedPrinters(context: Context): List<BluetoothPrinterDevice> {
        if (!hasBluetoothPermission(context)) return emptyList()
        return try {
            val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter = btManager?.adapter ?: return emptyList()
            if (!adapter.isEnabled) return emptyList()
            adapter.bondedDevices.orEmpty().map { device: BluetoothDevice ->
                BluetoothPrinterDevice(
                    name = device.name ?: "Printer Bluetooth",
                    address = device.address
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun sendEscPosToBluetooth(
        context: Context,
        macAddress: String,
        escPosBytes: ByteArray
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (!hasBluetoothPermission(context)) {
                return@withContext Result.failure(IllegalStateException("Izin Bluetooth belum diberikan."))
            }
            val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter = btManager?.adapter
                ?: return@withContext Result.failure(IllegalStateException("Perangkat tidak mendukung Bluetooth."))
            if (!adapter.isEnabled) {
                return@withContext Result.failure(IllegalStateException("Bluetooth sedang nonaktif. Aktifkan Bluetooth terlebih dahulu."))
            }
            val device = adapter.getRemoteDevice(macAddress)
            val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            adapter.cancelDiscovery()
            socket.connect()
            socket.outputStream.use { out ->
                out.write(escPosBytes)
                out.flush()
            }
            socket.close()
            Result.success("Struk berhasil dikirim ke printer ${device.name ?: macAddress}")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun buildEscPosReceiptBytes(
        txWithItems: TransactionWithItems,
        storeProfile: StoreProfileEntity,
        config: PrinterConfig
    ): ByteArray {
        val cols = if (config.paperWidthMm == 80) 48 else 32
        val out = ByteArrayOutputStream()

        // Initialize printer
        out.write(byteArrayOf(0x1B, 0x40))

        // Center align + Bold
        out.write(byteArrayOf(0x1B, 0x61, 0x01))
        out.write(byteArrayOf(0x1B, 0x45, 0x01))
        out.write("${storeProfile.storeName.uppercase()}\n".toByteArray())
        out.write(byteArrayOf(0x1B, 0x45, 0x00))
        out.write("${storeProfile.storeAddress}\n".toByteArray())
        out.write("Telp: ${storeProfile.storePhone}\n".toByteArray())
        out.write("${"=".repeat(cols)}\n".toByteArray())

        // Left align
        out.write(byteArrayOf(0x1B, 0x61, 0x00))
        val tx = txWithItems.transaction
        out.write(formatTwoColumns("No Struk", tx.invoiceNumber, cols))
        out.write(formatTwoColumns("Tanggal", FormatUtils.formatDateTime(tx.timestamp), cols))
        out.write(formatTwoColumns("Kasir", tx.cashierName, cols))
        out.write(formatTwoColumns("Pelanggan", tx.customerName, cols))
        out.write(formatTwoColumns("Bayar", tx.paymentMethod, cols))
        out.write("${"-".repeat(cols)}\n".toByteArray())

        txWithItems.items.forEach { item ->
            out.write("${item.productName.take(cols)}\n".toByteArray())
            val left = "  ${item.quantity} x ${FormatUtils.formatRupiah(item.sellPrice)}"
            val right = FormatUtils.formatRupiah(item.subtotal)
            out.write(formatTwoColumns(left, right, cols))
        }

        out.write("${"-".repeat(cols)}\n".toByteArray())
        out.write(formatTwoColumns("Subtotal", FormatUtils.formatRupiah(tx.subtotal), cols))
        if (tx.discountAmount > 0) {
            out.write(formatTwoColumns("Diskon", "-${FormatUtils.formatRupiah(tx.discountAmount)}", cols))
        }
        if (tx.taxAmount > 0) {
            out.write(formatTwoColumns("PPN", FormatUtils.formatRupiah(tx.taxAmount), cols))
        }

        // Bold Total
        out.write(byteArrayOf(0x1B, 0x45, 0x01))
        out.write(formatTwoColumns("TOTAL BAYAR", FormatUtils.formatRupiah(tx.totalAmount), cols))
        out.write(byteArrayOf(0x1B, 0x45, 0x00))

        out.write(formatTwoColumns("Dibayar", FormatUtils.formatRupiah(tx.amountPaid), cols))
        out.write(formatTwoColumns("Kembalian", FormatUtils.formatRupiah(tx.changeAmount), cols))
        out.write("${"=".repeat(cols)}\n".toByteArray())

        // Center footer
        out.write(byteArrayOf(0x1B, 0x61, 0x01))
        out.write("${storeProfile.receiptFooter}\n\n\n".toByteArray())

        // Kick cash drawer if enabled (ESC p 0 25 250)
        if (config.openCashDrawer) {
            out.write(byteArrayOf(0x1B, 0x70, 0x00, 0x19, 0xFA.toByte()))
        }

        // Partial cut paper (GS V 66 0)
        out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))
        return out.toByteArray()
    }

    fun buildTestPrintBytes(storeProfile: StoreProfileEntity, config: PrinterConfig): ByteArray {
        val cols = if (config.paperWidthMm == 80) 48 else 32
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1B, 0x40))
        out.write(byteArrayOf(0x1B, 0x61, 0x01))
        out.write(byteArrayOf(0x1B, 0x45, 0x01))
        out.write("TES CETAK KASIRPRO POS\n".toByteArray())
        out.write(byteArrayOf(0x1B, 0x45, 0x00))
        out.write("${storeProfile.storeName}\n".toByteArray())
        out.write("Ukuran Kertas: ${config.paperWidthMm}mm ($cols Karakter)\n".toByteArray())
        out.write("${"=".repeat(cols)}\n".toByteArray())
        out.write("Printer Thermal Siap Digunakan!\n\n\n".toByteArray())
        out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))
        return out.toByteArray()
    }

    private fun formatTwoColumns(left: String, right: String, width: Int): ByteArray {
        val space = (width - left.length - right.length).coerceAtLeast(1)
        val line = left.take(width - right.length - 1) + " ".repeat(space) + right + "\n"
        return line.toByteArray()
    }

    fun printViaAndroidPrintManager(
        context: Context,
        txWithItems: TransactionWithItems,
        storeProfile: StoreProfileEntity,
        paperWidthMm: Int = 58
    ): Result<String> {
        return try {
            val tx = txWithItems.transaction
            val widthPx = if (paperWidthMm == 80) 300 else 220
            val rowsHtml = txWithItems.items.joinToString("") { item ->
                """
                <tr>
                  <td colspan="2" style="padding-top:4px;font-weight:600;">${item.productName}</td>
                </tr>
                <tr>
                  <td style="color:#475569;">${item.quantity} x ${FormatUtils.formatRupiah(item.sellPrice)}</td>
                  <td style="text-align:right;font-weight:600;">${FormatUtils.formatRupiah(item.subtotal)}</td>
                </tr>
                """.trimIndent()
            }

            val html = """
                <html>
                <head>
                  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                  <style>
                    body { font-family: monospace; width: ${widthPx}px; margin: 0 auto; padding: 12px; color: #0F172A; font-size: 12px; }
                    h2 { text-align: center; margin: 0 0 4px 0; font-size: 15px; }
                    .center { text-align: center; }
                    .divider { border-top: 1px dashed #64748B; margin: 8px 0; }
                    table { width: 100%; border-collapse: collapse; font-size: 12px; }
                    .total { font-size: 14px; font-weight: bold; }
                  </style>
                </head>
                <body>
                  <h2>${storeProfile.storeName}</h2>
                  <div class="center">${storeProfile.storeAddress}</div>
                  <div class="center">Telp: ${storeProfile.storePhone}</div>
                  <div class="divider"></div>
                  <table>
                    <tr><td>No. Struk</td><td style="text-align:right;">${tx.invoiceNumber}</td></tr>
                    <tr><td>Tanggal</td><td style="text-align:right;">${FormatUtils.formatDateTime(tx.timestamp)}</td></tr>
                    <tr><td>Kasir</td><td style="text-align:right;">${tx.cashierName}</td></tr>
                    <tr><td>Pelanggan</td><td style="text-align:right;">${tx.customerName}</td></tr>
                    <tr><td>Metode</td><td style="text-align:right;">${tx.paymentMethod}</td></tr>
                  </table>
                  <div class="divider"></div>
                  <table>$rowsHtml</table>
                  <div class="divider"></div>
                  <table>
                    <tr><td>Subtotal</td><td style="text-align:right;">${FormatUtils.formatRupiah(tx.subtotal)}</td></tr>
                    ${if (tx.discountAmount > 0) "<tr><td>Diskon</td><td style='text-align:right;'>-${FormatUtils.formatRupiah(tx.discountAmount)}</td></tr>" else ""}
                    ${if (tx.taxAmount > 0) "<tr><td>PPN</td><td style='text-align:right;'>${FormatUtils.formatRupiah(tx.taxAmount)}</td></tr>" else ""}
                    <tr class="total"><td>TOTAL</td><td style="text-align:right;">${FormatUtils.formatRupiah(tx.totalAmount)}</td></tr>
                    <tr><td>Dibayar</td><td style="text-align:right;">${FormatUtils.formatRupiah(tx.amountPaid)}</td></tr>
                    <tr><td>Kembali</td><td style="text-align:right;">${FormatUtils.formatRupiah(tx.changeAmount)}</td></tr>
                  </table>
                  <div class="divider"></div>
                  <div class="center" style="margin-top:8px;">${storeProfile.receiptFooter}</div>
                </body>
                </html>
            """.trimIndent()

            val webView = WebView(context)
            webView.webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?) = false
                override fun onPageFinished(view: WebView, url: String?) {
                    try {
                        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                        val jobName = "Struk_${tx.invoiceNumber}"
                        val printAdapter = view.createPrintDocumentAdapter(jobName)
                        printManager?.print(
                            jobName,
                            printAdapter,
                            PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A7)
                                .build()
                        )
                    } catch (_: Exception) {
                    }
                }
            }
            webView.loadDataWithBaseURL(null, html, "text/HTML", "UTF-8", null)
            Result.success("Membuka layanan Cetak Sistem / PDF (${paperWidthMm}mm)...")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

@Composable
fun PrinterSettingsDialog(
    storeProfile: StoreProfileEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var config by remember { mutableStateOf(EscPosPrinterHelper.loadConfig(context)) }
    var pairedDevices by remember { mutableStateOf(EscPosPrinterHelper.getPairedPrinters(context)) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    val btPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        pairedDevices = EscPosPrinterHelper.getPairedPrinters(context)
        if (pairedDevices.isEmpty()) {
            statusMessage = "Belum ada printer Bluetooth yang dipasangkan (Paired) di pengaturan Android."
            isError = false
        }
    }

    LaunchedEffect(Unit) {
        if (!EscPosPrinterHelper.hasBluetoothPermission(context) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            btPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                )
            )
        } else {
            pairedDevices = EscPosPrinterHelper.getPairedPrinters(context)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("printer_settings_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "Pengaturan Printer",
                            tint = EmeraldPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Sistem Printer Kasir",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "Thermal Bluetooth ESC/POS & Cetak Sistem",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                // Paper Size Selector
                Text(
                    text = "Ukuran Kertas Thermal",
                    style = MaterialTheme.typography.titleSmall
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(
                        58 to "58mm (32 Karakter)",
                        80 to "80mm (48 Karakter)"
                    ).forEach { (widthMm, label) ->
                        val selected = config.paperWidthMm == widthMm
                        FilterChip(
                            selected = selected,
                            onClick = {
                                config = config.copy(paperWidthMm = widthMm)
                                EscPosPrinterHelper.saveConfig(context, config)
                            },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldPrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Toggles
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Cetak Struk Otomatis Saat Bayar", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Langsung kirim struk ke printer setelah transaksi selesai",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = config.autoPrintOnCheckout,
                        onCheckedChange = {
                            config = config.copy(autoPrintOnCheckout = it)
                            EscPosPrinterHelper.saveConfig(context, config)
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Buka Laci Kasir (Cash Drawer RJ11)", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Kirim sinyal elektrik pembuka laci uang saat cetak",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = config.openCashDrawer,
                        onCheckedChange = {
                            config = config.copy(openCashDrawer = it)
                            EscPosPrinterHelper.saveConfig(context, config)
                        }
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // Paired Bluetooth Devices Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bluetooth,
                            contentDescription = null,
                            tint = InfoBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Printer Bluetooth Terhubung",
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                    IconButton(
                        onClick = {
                            if (!EscPosPrinterHelper.hasBluetoothPermission(context) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                btPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.BLUETOOTH_CONNECT,
                                        Manifest.permission.BLUETOOTH_SCAN
                                    )
                                )
                            } else {
                                pairedDevices = EscPosPrinterHelper.getPairedPrinters(context)
                                statusMessage = "Daftar perangkat Bluetooth diperbarui (${pairedDevices.size} ditemukan)."
                                isError = false
                            }
                        }
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Muat Ulang Bluetooth")
                    }
                }

                if (pairedDevices.isEmpty()) {
                    Surface(
                        color = InfoSoft.copy(alpha = 0.65f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Belum ada printer Bluetooth yang dipasangkan.",
                                style = MaterialTheme.typography.titleSmall,
                                color = InfoBlue
                            )
                            Text(
                                text = "Pasangkan (Pair) printer thermal Bluetooth di Pengaturan Android, atau gunakan tombol 'Cetak Sistem / PDF' saat melihat struk.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF1E3A8A)
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        pairedDevices.forEach { device ->
                            val isSelected = config.selectedBtAddress == device.address
                            Surface(
                                color = if (isSelected) EmeraldSoft.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .then(
                                        if (isSelected) Modifier.border(1.5.dp, EmeraldPrimary, RoundedCornerShape(12.dp))
                                        else Modifier
                                    )
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        config = config.copy(
                                            selectedBtName = device.name,
                                            selectedBtAddress = device.address
                                        )
                                        EscPosPrinterHelper.saveConfig(context, config)
                                        statusMessage = "Printer utama dipilih: ${device.name}"
                                        isError = false
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (isSelected) Icons.Default.BluetoothConnected else Icons.Default.Bluetooth,
                                            contentDescription = null,
                                            tint = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = device.name,
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            Text(
                                                text = device.address,
                                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMono),
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "Terpilih",
                                            tint = EmeraldPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (statusMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = if (isError) DangerSoft else EmeraldSoft,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isError) DangerRed else EmeraldPrimary,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            if (config.selectedBtAddress.isBlank()) {
                                statusMessage = "Pilih printer Bluetooth terlebih dahulu atau pasangkan printer di pengaturan perangkat."
                                isError = true
                            } else {
                                scope.launch {
                                    statusMessage = "Mengirim tes cetak ke ${config.selectedBtName}..."
                                    isError = false
                                    val bytes = EscPosPrinterHelper.buildTestPrintBytes(storeProfile, config)
                                    val res = EscPosPrinterHelper.sendEscPosToBluetooth(
                                        context,
                                        config.selectedBtAddress,
                                        bytes
                                    )
                                    res.onSuccess { msg ->
                                        statusMessage = msg
                                        isError = false
                                    }.onFailure { err ->
                                        statusMessage = "Gagal terhubung ke printer: ${err.localizedMessage ?: "Pastikan printer menyala"}"
                                        isError = true
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("test_bluetooth_print_button")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Tes Cetak BT")
                    }

                    Button(
                        onClick = {
                            EscPosPrinterHelper.saveConfig(context, config)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_printer_settings_button")
                    ) {
                        Text("Simpan & Tutup")
                    }
                }
            }
        }
    }
}
