package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import com.example.data.ExpenseEntity
import com.example.data.ProductEntity
import com.example.data.StoreProfileEntity
import com.example.data.TransactionWithItems
import com.example.ui.DashboardAnalytics
import com.example.ui.FormatUtils
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.JetBrainsMono
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class CsvReportType(val title: String, val filePrefix: String) {
    TRANSACTIONS("Transaksi & Nota", "Laporan_Transaksi_KasirPro"),
    INVENTORY("Stok & Inventori", "Stok_Inventori_KasirPro"),
    PROFIT_LOSS("Laba Rugi & Kas", "Laba_Rugi_Kas_KasirPro")
}

object CsvExportHelper {

    private fun escapeCsv(value: String): String {
        val cleaned = value.replace("\"", "\"\"")
        return if (cleaned.contains(",") || cleaned.contains("\"") || cleaned.contains("\n")) {
            "\"$cleaned\""
        } else {
            cleaned
        }
    }

    fun buildTransactionsCsv(transactions: List<TransactionWithItems>): String {
        val sb = StringBuilder()
        sb.appendLine("No_Struk,Tanggal,Kasir,Pelanggan,Metode_Bayar,Status,Jumlah_Item,Subtotal_Rp,Diskon_Rp,PPN_Rp,Total_Bayar_Rp,Total_HPP_Rp,Laba_Kotor_Rp,Rincian_Barang")
        transactions.forEach { txWithItems ->
            val tx = txWithItems.transaction
            val totalQty = txWithItems.items.sumOf { it.quantity }
            val grossProfit = if (tx.status == "VOID") 0L else (tx.totalAmount - tx.taxAmount - tx.totalCost)
            val itemsDetail = txWithItems.items.joinToString("; ") { "${it.quantity}x ${it.productName} (@${it.sellPrice})" }
            sb.appendLine(
                listOf(
                    escapeCsv(tx.invoiceNumber),
                    escapeCsv(FormatUtils.formatDateTime(tx.timestamp)),
                    escapeCsv(tx.cashierName),
                    escapeCsv(tx.customerName),
                    escapeCsv(tx.paymentMethod),
                    escapeCsv(tx.status),
                    totalQty.toString(),
                    tx.subtotal.toString(),
                    tx.discountAmount.toString(),
                    tx.taxAmount.toString(),
                    tx.totalAmount.toString(),
                    tx.totalCost.toString(),
                    grossProfit.toString(),
                    escapeCsv(itemsDetail)
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun buildInventoryCsv(products: List<ProductEntity>): String {
        val sb = StringBuilder()
        sb.appendLine("SKU,Nama_Barang,Kategori,Satuan,Harga_Modal_HPP_Rp,Harga_Jual_Rp,Margin_Unit_Rp,Stok_Saat_Ini,Batas_Min_Stok,Total_Modal_Stok_Rp,Total_Nilai_Jual_Rp")
        products.forEach { p ->
            val unitMargin = p.sellPrice - p.buyPrice
            val totalCost = p.buyPrice * p.stock.coerceAtLeast(0)
            val totalRetail = p.sellPrice * p.stock.coerceAtLeast(0)
            sb.appendLine(
                listOf(
                    escapeCsv(p.sku),
                    escapeCsv(p.name),
                    escapeCsv(p.category),
                    escapeCsv(p.unit),
                    p.buyPrice.toString(),
                    p.sellPrice.toString(),
                    unitMargin.toString(),
                    p.stock.toString(),
                    p.minStockAlert.toString(),
                    totalCost.toString(),
                    totalRetail.toString()
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun buildProfitLossCsv(
        analytics: DashboardAnalytics,
        expenses: List<ExpenseEntity>,
        storeProfile: StoreProfileEntity
    ): String {
        val sb = StringBuilder()
        sb.appendLine("LAPORAN LABA RUGI & ARUS KAS - ${escapeCsv(storeProfile.storeName)}")
        sb.appendLine("Periode,${escapeCsv(analytics.period.label)}")
        sb.appendLine("Komponen,Nilai_Rp")
        sb.appendLine("Pendapatan Omzet Kotor,${analytics.grossRevenue}")
        sb.appendLine("Harga Pokok Penjualan (HPP),${analytics.totalCogs}")
        sb.appendLine("Laba Kotor Penjualan,${analytics.grossProfit}")
        sb.appendLine("Total Biaya Operasional,${analytics.totalExpenses}")
        sb.appendLine("Laba Bersih Usaha,${analytics.netProfit}")
        sb.appendLine("Margin Laba Bersih (%),${String.format(Locale.US, "%.2f", analytics.profitMarginPercent)}")
        sb.appendLine("Total Nota Selesai,${analytics.completedTxCount}")
        sb.appendLine("Total Produk Terjual,${analytics.totalItemsSold}")
        sb.appendLine()
        sb.appendLine("RINCIAN BIAYA OPERASIONAL")
        sb.appendLine("Tanggal,Judul_Pengeluaran,Kategori,Nominal_Rp,Catatan")
        expenses.forEach { exp ->
            sb.appendLine(
                listOf(
                    escapeCsv(FormatUtils.formatDateTime(exp.timestamp)),
                    escapeCsv(exp.title),
                    escapeCsv(exp.category),
                    exp.amount.toString(),
                    escapeCsv(exp.notes)
                ).joinToString(",")
            )
        }
        return sb.toString()
    }

    fun saveCsvToLocalFile(context: Context, reportType: CsvReportType, csvContent: String): File {
        val dateStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "${reportType.filePrefix}_$dateStamp.csv"

        val exportDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "exports").apply {
            if (!exists()) mkdirs()
        }
        val outFile = File(exportDir, fileName)
        outFile.writeText(csvContent, Charsets.UTF_8)

        // Also write a copy in cacheDir/exports for FileProvider sharing
        val cacheExportDir = File(context.cacheDir, "exports").apply {
            if (!exists()) mkdirs()
        }
        val shareFile = File(cacheExportDir, fileName)
        shareFile.writeText(csvContent, Charsets.UTF_8)
        return shareFile
    }

    fun shareCsvFile(context: Context, reportType: CsvReportType, csvContent: String): Result<String> {
        return try {
            val file = saveCsvToLocalFile(context, reportType, csvContent)
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_SUBJECT, "${reportType.title} - KasirPro POS")
                putExtra(Intent.EXTRA_TEXT, csvContent)
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Ekspor / Bagikan File CSV"))
            Result.success("File ${file.name} berhasil dibuat & siap dibagikan.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

@Composable
fun CsvExportDialog(
    initialType: CsvReportType = CsvReportType.TRANSACTIONS,
    transactions: List<TransactionWithItems>,
    products: List<ProductEntity>,
    expenses: List<ExpenseEntity>,
    analytics: DashboardAnalytics,
    storeProfile: StoreProfileEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedType by remember { mutableStateOf(initialType) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val csvContent by remember(selectedType, transactions, products, expenses, analytics, storeProfile) {
        derivedStateOf {
            when (selectedType) {
                CsvReportType.TRANSACTIONS -> CsvExportHelper.buildTransactionsCsv(transactions)
                CsvReportType.INVENTORY -> CsvExportHelper.buildInventoryCsv(products)
                CsvReportType.PROFIT_LOSS -> CsvExportHelper.buildProfitLossCsv(analytics, expenses, storeProfile)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("csv_export_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.TableView,
                            contentDescription = "Ekspor CSV",
                            tint = EmeraldPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Ekspor Data CSV (Excel / Spreadsheet)",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "Pilih laporan untuk disimpan atau dibagikan",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                // Report Type Filter Chips
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(CsvReportType.entries) { type ->
                        val selected = selectedType == type
                        FilterChip(
                            selected = selected,
                            onClick = {
                                selectedType = type
                                statusMessage = null
                            },
                            label = { Text(type.title) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldPrimary,
                                selectedLabelColor = Color.White
                            ),
                            modifier = Modifier.testTag("csv_type_${type.name}")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // CSV Live Preview Box
                Text(
                    text = "Pratinjau Isi File CSV (${csvContent.lines().filter { it.isNotBlank() }.size} Baris):",
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .background(
                            Color(0xFF0F172A),
                            RoundedCornerShape(14.dp)
                        )
                        .padding(12.dp)
                ) {
                    Text(
                        text = csvContent,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMono),
                        color = EmeraldSoft,
                        modifier = Modifier
                            .verticalScroll(rememberScrollState())
                            .horizontalScroll(rememberScrollState())
                    )
                }

                if (statusMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = EmeraldSoft,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = statusMessage!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = EmeraldDark
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons: Save Locally, Copy CSV, Share/Open File
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val savedFile = CsvExportHelper.saveCsvToLocalFile(context, selectedType, csvContent)
                            statusMessage = "Tersimpan di penyimpanan lokal: ${savedFile.name}"
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_csv_local_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Simpan CSV", style = MaterialTheme.typography.labelMedium)
                    }

                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            clipboard?.setPrimaryClip(ClipData.newPlainText(selectedType.title, csvContent))
                            statusMessage = "Data CSV berhasil disalin ke Clipboard!"
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("copy_csv_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Salin Teks", style = MaterialTheme.typography.labelMedium)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        val res = CsvExportHelper.shareCsvFile(context, selectedType, csvContent)
                        res.onSuccess { msg -> statusMessage = msg }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("share_csv_file_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Ekspor & Bagikan File .CSV (${selectedType.title})",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}
