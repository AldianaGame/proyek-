package com.example.data

import kotlinx.coroutines.flow.Flow

class KasirRepository(private val dao: KasirDao) {

    val activeProducts: Flow<List<ProductEntity>> = dao.getAllActiveProducts()
    val transactionsWithItems: Flow<List<TransactionWithItems>> = dao.getAllTransactionsWithItems()
    val expenses: Flow<List<ExpenseEntity>> = dao.getAllExpenses()
    val storeProfile: Flow<StoreProfileEntity?> = dao.getStoreProfile()

    suspend fun saveProduct(product: ProductEntity) {
        if (product.id == 0L) {
            dao.insertProduct(product)
        } else {
            dao.updateProduct(product)
        }
    }

    suspend fun deleteProduct(productId: Long) {
        dao.softDeleteProduct(productId)
    }

    suspend fun adjustStock(productId: Long, delta: Int) {
        dao.adjustStock(productId, delta)
    }

    suspend fun recordSale(
        transaction: TransactionEntity,
        items: List<TransactionItemEntity>
    ): Long {
        return dao.createSaleTransaction(transaction, items)
    }

    suspend fun voidTransaction(transactionWithItems: TransactionWithItems) {
        if (transactionWithItems.transaction.status != "VOID") {
            dao.voidTransaction(
                transactionWithItems.transaction.id,
                transactionWithItems.items
            )
        }
    }

    suspend fun addExpense(expense: ExpenseEntity) {
        dao.insertExpense(expense)
    }

    suspend fun deleteExpense(expense: ExpenseEntity) {
        dao.deleteExpense(expense)
    }

    suspend fun saveStoreProfile(profile: StoreProfileEntity) {
        dao.saveStoreProfile(profile)
    }

    suspend fun seedInitialDataIfEmpty() {
        val count = dao.getProductCount()
        if (count > 0) return

        dao.saveStoreProfile(StoreProfileEntity())

        val initialProducts = listOf(
            ProductEntity(
                id = 1,
                sku = "KOP-001",
                name = "Es Kopi Susu Gula Aren",
                category = "Kopi Signature",
                buyPrice = 9500,
                sellPrice = 22000,
                stock = 64,
                minStockAlert = 15,
                unit = "Cup",
                colorHex = "#065F46"
            ),
            ProductEntity(
                id = 2,
                sku = "KOP-002",
                name = "Caramel Macchiato Iced",
                category = "Kopi Signature",
                buyPrice = 12000,
                sellPrice = 28000,
                stock = 42,
                minStockAlert = 10,
                unit = "Cup",
                colorHex = "#047857"
            ),
            ProductEntity(
                id = 3,
                sku = "KOP-003",
                name = "V60 Manual Brew Gayo Wine",
                category = "Kopi Signature",
                buyPrice = 11000,
                sellPrice = 26000,
                stock = 28,
                minStockAlert = 8,
                unit = "Cup",
                colorHex = "#065F46"
            ),
            ProductEntity(
                id = 4,
                sku = "KOP-004",
                name = "Double Iced Shaken Espresso",
                category = "Kopi Signature",
                buyPrice = 10500,
                sellPrice = 25000,
                stock = 5, // Low stock alert demo!
                minStockAlert = 10,
                unit = "Cup",
                colorHex = "#064E3B"
            ),
            ProductEntity(
                id = 5,
                sku = "NON-001",
                name = "Uji Matcha Latte Creamy",
                category = "Non-Kopi",
                buyPrice = 13000,
                sellPrice = 27000,
                stock = 36,
                minStockAlert = 10,
                unit = "Cup",
                colorHex = "#15803D"
            ),
            ProductEntity(
                id = 6,
                sku = "NON-002",
                name = "Belgian Dark Chocolate",
                category = "Non-Kopi",
                buyPrice = 12500,
                sellPrice = 26000,
                stock = 30,
                minStockAlert = 10,
                unit = "Cup",
                colorHex = "#7C2D12"
            ),
            ProductEntity(
                id = 7,
                sku = "NON-003",
                name = "Lychee Yakult Sparkle",
                category = "Non-Kopi",
                buyPrice = 9000,
                sellPrice = 23000,
                stock = 4, // Low stock alert demo!
                minStockAlert = 8,
                unit = "Cup",
                colorHex = "#BE123C"
            ),
            ProductEntity(
                id = 8,
                sku = "PAS-001",
                name = "Butter Croissant Artisan",
                category = "Pastry & Snack",
                buyPrice = 11000,
                sellPrice = 24000,
                stock = 18,
                minStockAlert = 6,
                unit = "Pcs",
                colorHex = "#D97706"
            ),
            ProductEntity(
                id = 9,
                sku = "PAS-002",
                name = "Pain au Chocolat Almond",
                category = "Pastry & Snack",
                buyPrice = 13500,
                sellPrice = 28000,
                stock = 3, // Low stock alert demo!
                minStockAlert = 6,
                unit = "Pcs",
                colorHex = "#B45309"
            ),
            ProductEntity(
                id = 10,
                sku = "PAS-003",
                name = "Truffle French Fries",
                category = "Pastry & Snack",
                buyPrice = 11500,
                sellPrice = 25000,
                stock = 32,
                minStockAlert = 8,
                unit = "Porsi",
                colorHex = "#CA8A04"
            ),
            ProductEntity(
                id = 11,
                sku = "MAK-001",
                name = "Ricebowl Chicken Sambal Matah",
                category = "Makanan Berat",
                buyPrice = 16500,
                sellPrice = 35000,
                stock = 25,
                minStockAlert = 8,
                unit = "Porsi",
                colorHex = "#B91C1C"
            ),
            ProductEntity(
                id = 12,
                sku = "MAK-002",
                name = "Beef Gyudon Onsen Egg",
                category = "Makanan Berat",
                buyPrice = 22000,
                sellPrice = 45000,
                stock = 20,
                minStockAlert = 6,
                unit = "Porsi",
                colorHex = "#991B1B"
            ),
            ProductEntity(
                id = 13,
                sku = "MRC-001",
                name = "House Blend Arabica 250g",
                category = "Beans & Retail",
                buyPrice = 52000,
                sellPrice = 95000,
                stock = 14,
                minStockAlert = 5,
                unit = "Pack",
                colorHex = "#1E40AF"
            ),
            ProductEntity(
                id = 14,
                sku = "MRC-002",
                name = "Tumbler Stainless Vacuum 500ml",
                category = "Beans & Retail",
                buyPrice = 68000,
                sellPrice = 135000,
                stock = 2, // Low stock alert demo!
                minStockAlert = 4,
                unit = "Pcs",
                colorHex = "#4338CA"
            )
        )
        dao.insertProducts(initialProducts)

        val now = System.currentTimeMillis()
        val hourMs = 3600_000L
        val dayMs = 24 * hourMs

        // Seed realistic historical transactions across last 7 days + today
        data class SeedSale(
            val invSuffix: String,
            val timeOffsetMs: Long,
            val customer: String,
            val paymentMethod: String,
            val discount: Long,
            val productQtys: List<Pair<ProductEntity, Int>>
        )

        val pMap = initialProducts.associateBy { it.id }
        val seedSales = listOf(
            // Today
            SeedSale(
                invSuffix = "089",
                timeOffsetMs = 1 * hourMs,
                customer = "Budi Santoso",
                paymentMethod = "QRIS",
                discount = 0L,
                productQtys = listOf(pMap[1]!! to 3, pMap[8]!! to 2, pMap[11]!! to 2)
            ),
            SeedSale(
                invSuffix = "088",
                timeOffsetMs = 2 * hourMs,
                customer = "Rina Wijaya",
                paymentMethod = "TUNAI",
                discount = 5000L,
                productQtys = listOf(pMap[2]!! to 2, pMap[5]!! to 2, pMap[10]!! to 1)
            ),
            SeedSale(
                invSuffix = "087",
                timeOffsetMs = 4 * hourMs,
                customer = "Andi Pratama",
                paymentMethod = "DEBIT",
                discount = 0L,
                productQtys = listOf(pMap[13]!! to 2, pMap[3]!! to 2, pMap[12]!! to 1)
            ),
            SeedSale(
                invSuffix = "086",
                timeOffsetMs = 5 * hourMs,
                customer = "Pelanggan Umum",
                paymentMethod = "QRIS",
                discount = 0L,
                productQtys = listOf(pMap[1]!! to 4, pMap[9]!! to 2)
            ),
            // Yesterday (1 day ago)
            SeedSale(
                invSuffix = "085",
                timeOffsetMs = 1 * dayMs + 2 * hourMs,
                customer = "PT Kreatif Digital",
                paymentMethod = "TRANSFER",
                discount = 15000L,
                productQtys = listOf(pMap[1]!! to 8, pMap[8]!! to 6, pMap[5]!! to 4)
            ),
            SeedSale(
                invSuffix = "084",
                timeOffsetMs = 1 * dayMs + 5 * hourMs,
                customer = "Dewi Lestari",
                paymentMethod = "QRIS",
                discount = 0L,
                productQtys = listOf(pMap[12]!! to 2, pMap[6]!! to 2, pMap[14]!! to 1)
            ),
            // 2 days ago
            SeedSale(
                invSuffix = "083",
                timeOffsetMs = 2 * dayMs + 3 * hourMs,
                customer = "Hendra Gunawan",
                paymentMethod = "TUNAI",
                discount = 0L,
                productQtys = listOf(pMap[1]!! to 5, pMap[11]!! to 3, pMap[10]!! to 2)
            ),
            SeedSale(
                invSuffix = "082",
                timeOffsetMs = 2 * dayMs + 6 * hourMs,
                customer = "Siti Aminah",
                paymentMethod = "DEBIT",
                discount = 0L,
                productQtys = listOf(pMap[2]!! to 4, pMap[5]!! to 3, pMap[8]!! to 3)
            ),
            // 3 days ago
            SeedSale(
                invSuffix = "081",
                timeOffsetMs = 3 * dayMs + 2 * hourMs,
                customer = "Reza Rahadian",
                paymentMethod = "QRIS",
                discount = 10000L,
                productQtys = listOf(pMap[13]!! to 3, pMap[1]!! to 4, pMap[9]!! to 3)
            ),
            // 4 days ago
            SeedSale(
                invSuffix = "080",
                timeOffsetMs = 4 * dayMs + 4 * hourMs,
                customer = "Komunitas Sepeda JKT",
                paymentMethod = "QRIS",
                discount = 0L,
                productQtys = listOf(pMap[1]!! to 10, pMap[4]!! to 4, pMap[8]!! to 5)
            ),
            // 5 days ago
            SeedSale(
                invSuffix = "079",
                timeOffsetMs = 5 * dayMs + 3 * hourMs,
                customer = "Fajar Nugroho",
                paymentMethod = "TUNAI",
                discount = 0L,
                productQtys = listOf(pMap[11]!! to 4, pMap[12]!! to 2, pMap[7]!! to 4)
            ),
            // 6 days ago
            SeedSale(
                invSuffix = "078",
                timeOffsetMs = 6 * dayMs + 3 * hourMs,
                customer = "Maya Sari",
                paymentMethod = "DEBIT",
                discount = 0L,
                productQtys = listOf(pMap[14]!! to 2, pMap[2]!! to 3, pMap[6]!! to 2)
            )
        )

        for (sale in seedSales.reversed()) {
            val subtotal = sale.productQtys.sumOf { (p, qty) -> p.sellPrice * qty }
            val totalCost = sale.productQtys.sumOf { (p, qty) -> p.buyPrice * qty }
            val taxable = (subtotal - sale.discount).coerceAtLeast(0L)
            val tax = (taxable * 10L) / 100L
            val total = taxable + tax
            val paid = if (sale.paymentMethod == "TUNAI") {
                ((total + 49999L) / 50000L) * 50000L
            } else {
                total
            }
            val txId = dao.insertTransaction(
                TransactionEntity(
                    invoiceNumber = "INV-2610-${sale.invSuffix}",
                    timestamp = now - sale.timeOffsetMs,
                    customerName = sale.customer,
                    subtotal = subtotal,
                    discountAmount = sale.discount,
                    taxAmount = tax,
                    totalAmount = total,
                    totalCost = totalCost,
                    paymentMethod = sale.paymentMethod,
                    amountPaid = paid,
                    changeAmount = paid - total,
                    cashierName = "Nadia Putri",
                    notes = "Transaksi Kasir POS",
                    status = "COMPLETED"
                )
            )
            val txItems = sale.productQtys.map { (p, qty) ->
                TransactionItemEntity(
                    transactionId = txId,
                    productId = p.id,
                    productName = p.name,
                    sku = p.sku,
                    category = p.category,
                    buyPrice = p.buyPrice,
                    sellPrice = p.sellPrice,
                    quantity = qty,
                    subtotal = p.sellPrice * qty
                )
            }
            dao.insertTransactionItems(txItems)
        }

        // Seed operational expenses
        val seedExpenses = listOf(
            ExpenseEntity(
                title = "Restock Susu Fresh Milk & Oatmilk 2 Karton",
                category = "Bahan Baku",
                amount = 145000L,
                timestamp = now - 3 * hourMs,
                notes = "Supplier Greenfields"
            ),
            ExpenseEntity(
                title = "Pembelian Cup Paper & Lid 500 Pcs",
                category = "Operasional",
                amount = 95000L,
                timestamp = now - 1 * dayMs - 4 * hourMs,
                notes = "Kemasan takeaway"
            ),
            ExpenseEntity(
                title = "Token Listrik & Internet Toko",
                category = "Listrik & Air",
                amount = 210000L,
                timestamp = now - 3 * dayMs,
                notes = "PLN & IndiHome Biz"
            ),
            ExpenseEntity(
                title = "Es Batu Kristal & Air Galon",
                category = "Bahan Baku",
                amount = 65000L,
                timestamp = now - 4 * dayMs,
                notes = "Rutin mingguan"
            )
        )
        dao.insertExpenses(seedExpenses)
    }
}
