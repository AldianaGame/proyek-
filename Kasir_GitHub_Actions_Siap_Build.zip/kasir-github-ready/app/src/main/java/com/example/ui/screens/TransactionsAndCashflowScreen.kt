package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.ExpenseEntity
import com.example.data.TransactionWithItems
import com.example.ui.DashboardAnalytics
import com.example.ui.FormatUtils
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerSoft
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.JetBrainsMono

@Composable
fun TransactionsAndCashflowScreen(
    transactions: List<TransactionWithItems>,
    expenses: List<ExpenseEntity>,
    analytics: DashboardAnalytics,
    onSelectTransaction: (TransactionWithItems) -> Unit,
    onAddExpense: (title: String, category: String, amount: Long, notes: String) -> Unit,
    onDeleteExpense: (ExpenseEntity) -> Unit,
    onExportCsv: () -> Unit = {}
) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedMethodFilter by remember { mutableStateOf("Semua") }
    var showAddExpenseDialog by remember { mutableStateOf(false) }

    val filteredTransactions by remember(transactions, searchQuery, selectedMethodFilter) {
        derivedStateOf {
            transactions.filter { txWithItems ->
                val tx = txWithItems.transaction
                val matchesMethod = when (selectedMethodFilter) {
                    "Semua" -> true
                    "VOID" -> tx.status == "VOID"
                    else -> tx.paymentMethod == selectedMethodFilter && tx.status == "COMPLETED"
                }
                val q = searchQuery.trim().lowercase()
                val matchesSearch = q.isEmpty() ||
                    tx.invoiceNumber.lowercase().contains(q) ||
                    tx.customerName.lowercase().contains(q) ||
                    txWithItems.items.any { it.productName.lowercase().contains(q) }
                matchesMethod && matchesSearch
            }
        }
    }

    Scaffold(
        floatingActionButton = {
            if (selectedSubTab == 1) {
                FloatingActionButton(
                    onClick = { showAddExpenseDialog = true },
                    containerColor = DangerRed,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_expense_fab")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Catat Pengeluaran")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Catat Biaya", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
                .testTag("transactions_cashflow_screen")
        ) {
            TabRow(
                selectedTabIndex = selectedSubTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Tab(
                    selected = selectedSubTab == 0,
                    onClick = { selectedSubTab = 0 },
                    text = { Text("Riwayat Nota (${transactions.size})") },
                    modifier = Modifier.testTag("subtab_transactions")
                )
                Tab(
                    selected = selectedSubTab == 1,
                    onClick = { selectedSubTab = 1 },
                    text = { Text("Laporan Laba Rugi & Kas") },
                    modifier = Modifier.testTag("subtab_cashflow")
                )
            }

            if (selectedSubTab == 0) {
                // SUB-TAB 0: TRANSACTIONS HISTORY
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = { Text("Cari nomor struk, pelanggan, item...") },
                                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("transaction_search_input")
                                )
                                Button(
                                    onClick = onExportCsv,
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    shape = RoundedCornerShape(14.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 14.dp),
                                    modifier = Modifier.testTag("transactions_export_csv_button")
                                ) {
                                    Text("Ekspor CSV", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            val methods = listOf("Semua", "TUNAI", "QRIS", "DEBIT", "TRANSFER", "VOID")
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(methods) { method ->
                                    FilterChip(
                                        selected = selectedMethodFilter == method,
                                        onClick = { selectedMethodFilter = method },
                                        label = { Text(method) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = if (method == "VOID") DangerRed else EmeraldPrimary,
                                            selectedLabelColor = Color.White
                                        )
                                    )
                                }
                            }
                        }
                    }

                    items(filteredTransactions, key = { it.transaction.id }) { txWithItems ->
                        TransactionHistoryCard(
                            txWithItems = txWithItems,
                            onClick = { onSelectTransaction(txWithItems) }
                        )
                    }
                }
            } else {
                // SUB-TAB 1: PROFIT & LOSS STATEMENT + EXPENSES
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        ProfitLossStatementCard(
                            analytics = analytics,
                            onExportCsv = onExportCsv
                        )
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Catatan Biaya Operasional",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "Pengeluaran kas toko mengurangi laba bersih",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    items(expenses, key = { it.id }) { expense ->
                        ExpenseItemCard(
                            expense = expense,
                            onDelete = { onDeleteExpense(expense) }
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(72.dp))
                    }
                }
            }
        }
    }

    if (showAddExpenseDialog) {
        AddExpenseDialog(
            onDismiss = { showAddExpenseDialog = false },
            onSave = { title, category, amount, notes ->
                onAddExpense(title, category, amount, notes)
                showAddExpenseDialog = false
            }
        )
    }
}

@Composable
private fun TransactionHistoryCard(
    txWithItems: TransactionWithItems,
    onClick: () -> Unit
) {
    val tx = txWithItems.transaction
    val isVoid = tx.status == "VOID"
    val txProfit = tx.totalAmount - tx.taxAmount - tx.totalCost

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("transaction_card_${tx.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                if (isVoid) DangerSoft else EmeraldSoft,
                                RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ReceiptLong,
                            contentDescription = null,
                            tint = if (isVoid) DangerRed else EmeraldPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = tx.invoiceNumber,
                            style = MaterialTheme.typography.titleSmall.copy(fontFamily = JetBrainsMono)
                        )
                        Text(
                            text = "${tx.customerName} • ${FormatUtils.formatDateTime(tx.timestamp)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    color = if (isVoid) DangerSoft else GoldSoft,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (isVoid) "VOID" else tx.paymentMethod,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (isVoid) DangerRed else GoldAccent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Items preview line
            val itemsSummary = txWithItems.items.joinToString(", ") { "${it.quantity}x ${it.productName}" }
            Text(
                text = itemsSummary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isVoid) "Dibatalkan (Stok dikembalikan)" else "Laba Nota: +${FormatUtils.formatRupiah(txProfit)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isVoid) DangerRed else EmeraldPrimary
                )
                Text(
                    text = FormatUtils.formatRupiah(tx.totalAmount),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = JetBrainsMono,
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (isVoid) DangerRed else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun ProfitLossStatementCard(
    analytics: DashboardAnalytics,
    onExportCsv: () -> Unit = {}
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldDark)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountBalanceWallet,
                        contentDescription = null,
                        tint = GoldBright
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Laporan Laba Rugi (${analytics.period.label})",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                }
                Surface(
                    onClick = onExportCsv,
                    color = GoldBright,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("cashflow_export_csv_button")
                ) {
                    Text(
                        text = "Ekspor CSV",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            StatementLine(
                label = "(+) Pendapatan Omzet Penjualan",
                value = FormatUtils.formatRupiah(analytics.grossRevenue),
                valueColor = Color.White
            )
            StatementLine(
                label = "(-) Harga Pokok Penjualan (HPP)",
                value = "- ${FormatUtils.formatRupiah(analytics.totalCogs)}",
                valueColor = Color(0xFFFCA5A5)
            )

            HorizontalDivider(
                color = Color.White.copy(alpha = 0.2f),
                modifier = Modifier.padding(vertical = 8.dp)
            )

            StatementLine(
                label = "(=) Laba Kotor Penjualan",
                value = FormatUtils.formatRupiah(analytics.grossProfit),
                valueColor = EmeraldSoft,
                isBold = true
            )
            StatementLine(
                label = "(-) Biaya Operasional Toko",
                value = "- ${FormatUtils.formatRupiah(analytics.totalExpenses)}",
                valueColor = Color(0xFFFCA5A5)
            )

            HorizontalDivider(
                color = Color.White.copy(alpha = 0.25f),
                modifier = Modifier.padding(vertical = 10.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LABA BERSIH USAHA",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = GoldBright
                    )
                    Text(
                        text = "Margin Bersih: ${String.format("%.1f", analytics.profitMarginPercent)}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldSoft
                    )
                }
                Text(
                    text = FormatUtils.formatRupiah(analytics.netProfit),
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = JetBrainsMono,
                        fontWeight = FontWeight.Bold
                    ),
                    color = GoldBright
                )
            }
        }
    }
}

@Composable
private fun StatementLine(
    label: String,
    value: String,
    valueColor: Color,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = if (isBold) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodyMedium,
            color = Color(0xFFE2E8F0)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium
            ),
            color = valueColor
        )
    }
}

@Composable
private fun ExpenseItemCard(
    expense: ExpenseEntity,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(DangerSoft, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.RequestQuote,
                        contentDescription = null,
                        tint = DangerRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = expense.title,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "${expense.category} • ${FormatUtils.formatDateTime(expense.timestamp)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (expense.notes.isNotBlank()) {
                        Text(
                            text = expense.notes,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "- ${FormatUtils.formatRupiah(expense.amount)}",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = DangerRed
                )
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Hapus Pengeluaran",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (title: String, category: String, amount: Long, notes: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Bahan Baku") }
    var amountText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val categories = listOf("Bahan Baku", "Operasional", "Listrik & Air", "Gaji", "Lainnya")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("add_expense_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Catat Pengeluaran Toko",
                        style = MaterialTheme.typography.titleLarge
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Nama Pengeluaran / Keperluan") },
                    placeholder = { Text("Contoh: Beli Susu & Cup") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_title_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Kategori Biaya", style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                    label = { Text("Nominal Biaya (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("expense_amount_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Catatan Supplier / Keterangan") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Batal")
                    }
                    Button(
                        onClick = {
                            val amt = amountText.toLongOrNull() ?: 0L
                            if (title.isNotBlank() && amt > 0L) {
                                onSave(title, category, amt, notes)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_expense_button")
                    ) {
                        Text("Simpan")
                    }
                }
            }
        }
    }
}
