package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AddBusiness
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ProductEntity
import com.example.data.StoreProfileEntity
import com.example.data.TransactionWithItems
import com.example.ui.CategoryStat
import com.example.ui.DailyTrendPoint
import com.example.ui.DashboardAnalytics
import com.example.ui.DashboardPeriod
import com.example.ui.FormatUtils
import com.example.ui.PaymentMethodStat
import com.example.ui.TopProductStat
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerSoft
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldVibrant
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.InfoSoft
import com.example.ui.theme.JetBrainsMono
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.PurpleSoft

@Composable
fun DashboardScreen(
    analytics: DashboardAnalytics,
    storeProfile: StoreProfileEntity,
    recentTransactions: List<TransactionWithItems>,
    onSelectPeriod: (DashboardPeriod) -> Unit,
    onOpenCashier: () -> Unit,
    onOpenInventory: () -> Unit,
    onOpenSettings: () -> Unit,
    onExportCsv: () -> Unit,
    onQuickRestock: (Long, Int) -> Unit,
    onSelectTransaction: (TransactionWithItems) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Header Banner with Store Identity & Quick POS Action
        item {
            DashboardHeroHeader(
                storeProfile = storeProfile,
                todayRevenue = analytics.todayRevenue,
                dailyTarget = analytics.dailyTarget,
                targetProgress = analytics.dailyTargetProgress,
                onOpenCashier = onOpenCashier,
                onOpenSettings = onOpenSettings
            )
        }

        // 2. Period Filter Bar
        item {
            PeriodSelectorRow(
                selectedPeriod = analytics.period,
                onSelectPeriod = onSelectPeriod,
                onExportCsv = onExportCsv
            )
        }

        // 3. 4 Executive KPI Cards (2x2 Grid)
        item {
            ExecutiveKpiGrid(analytics = analytics)
        }

        // 4. Interactive 7-Day Revenue & Profit Trend Chart
        item {
            RevenueTrendChartCard(dailyTrend = analytics.dailyTrend)
        }

        // 5. Category & Payment Method Donut Analytics
        item {
            CategoryAndPaymentBreakdownCard(
                categoryStats = analytics.categoryStats,
                paymentStats = analytics.paymentStats
            )
        }

        // 6. Top Selling Products Leaderboard
        item {
            TopProductsLeaderboardCard(topProducts = analytics.topProducts)
        }

        // 7. Low Stock Alerts (With Quick +10 Restock Button)
        if (analytics.lowStockProducts.isNotEmpty()) {
            item {
                LowStockAlertCard(
                    lowStockProducts = analytics.lowStockProducts,
                    onQuickRestock = onQuickRestock,
                    onOpenInventory = onOpenInventory
                )
            }
        }

        // 8. Recent Transactions List
        item {
            RecentTransactionsCard(
                transactions = recentTransactions.take(5),
                onSelectTransaction = onSelectTransaction
            )
        }
    }
}

@Composable
private fun DashboardHeroHeader(
    storeProfile: StoreProfileEntity,
    todayRevenue: Long,
    dailyTarget: Long,
    targetProgress: Float,
    onOpenCashier: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val animatedProgress by animateFloatAsState(
        targetValue = targetProgress.coerceIn(0f, 1f),
        animationSpec = tween(700),
        label = "targetProgress"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(26.dp))
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_pos_hero),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .matchParentSize()
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            EmeraldDark.copy(alpha = 0.93f),
                            Color(0xFF0F172A).copy(alpha = 0.88f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Surface(
                        color = EmeraldVibrant.copy(alpha = 0.22f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "KASIR PRO • ${storeProfile.cashierName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldSoft,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = storeProfile.storeName,
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = storeProfile.storeAddress,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.14f), CircleShape)
                        .testTag("open_store_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Pengaturan Toko",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Daily Sales Target Card inside Hero
            Surface(
                color = Color.White.copy(alpha = 0.11f),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "Omzet Hari Ini vs Target Harian",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFCBD5E1)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = FormatUtils.formatRupiah(todayRevenue),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontFamily = JetBrainsMono,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = GoldBright
                            )
                        }
                        Text(
                            text = "${(targetProgress * 100).toInt()}% dari ${FormatUtils.formatCompactRupiah(dailyTarget)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = EmeraldSoft
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = GoldBright,
                        trackColor = Color.White.copy(alpha = 0.2f),
                        strokeCap = StrokeCap.Round
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onOpenCashier,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldBright,
                    contentColor = Color(0xFF0F172A)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hero_open_pos_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PointOfSale,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Buka Mesin Kasir POS Baru",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Composable
private fun PeriodSelectorRow(
    selectedPeriod: DashboardPeriod,
    onSelectPeriod: (DashboardPeriod) -> Unit,
    onExportCsv: () -> Unit
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Ringkasan Performa Bisnis",
                style = MaterialTheme.typography.titleMedium
            )
            androidx.compose.material3.OutlinedButton(
                onClick = onExportCsv,
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier.testTag("dashboard_export_csv_button")
            ) {
                Text(
                    text = "Ekspor CSV",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(DashboardPeriod.entries) { period ->
                val selected = period == selectedPeriod
                FilterChip(
                    selected = selected,
                    onClick = { onSelectPeriod(period) },
                    label = {
                        Text(
                            text = period.label,
                            style = MaterialTheme.typography.labelLarge
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.testTag("period_chip_${period.name}")
                )
            }
        }
    }
}

@Composable
private fun ExecutiveKpiGrid(analytics: DashboardAnalytics) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            KpiStatCard(
                modifier = Modifier.weight(1f),
                title = "Total Omzet",
                value = FormatUtils.formatCompactRupiah(analytics.grossRevenue),
                subValue = "HPP: ${FormatUtils.formatCompactRupiah(analytics.totalCogs)}",
                icon = Icons.AutoMirrored.Filled.TrendingUp,
                iconBg = EmeraldSoft,
                iconTint = EmeraldPrimary
            )
            KpiStatCard(
                modifier = Modifier.weight(1f),
                title = "Laba Bersih",
                value = FormatUtils.formatCompactRupiah(analytics.netProfit),
                subValue = "Margin ${String.format("%.1f", analytics.profitMarginPercent)}%",
                icon = Icons.Default.AccountBalanceWallet,
                iconBg = GoldSoft,
                iconTint = GoldAccent
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            KpiStatCard(
                modifier = Modifier.weight(1f),
                title = "Total Transaksi",
                value = "${analytics.completedTxCount} Nota",
                subValue = "Rata2: ${FormatUtils.formatCompactRupiah(analytics.averageOrderValue)}",
                icon = Icons.AutoMirrored.Filled.ReceiptLong,
                iconBg = InfoSoft,
                iconTint = InfoBlue
            )
            KpiStatCard(
                modifier = Modifier.weight(1f),
                title = "Item Terjual",
                value = "${analytics.totalItemsSold} Produk",
                subValue = "Biaya: ${FormatUtils.formatCompactRupiah(analytics.totalExpenses)}",
                icon = Icons.Default.Inventory2,
                iconBg = PurpleSoft,
                iconTint = PurpleAccent
            )
        }
    }
}

@Composable
private fun KpiStatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subValue: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Color,
    iconTint: Color
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(iconBg, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = JetBrainsMono,
                    fontWeight = FontWeight.Bold
                ),
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subValue,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun RevenueTrendChartCard(dailyTrend: List<DailyTrendPoint>) {
    var selectedBarIndex by remember(dailyTrend) {
        mutableIntStateOf((dailyTrend.size - 1).coerceAtLeast(0))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Grafik Tren Omzet & Laba Kotor (7 Hari)",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Ketuk batang grafik untuk rincian harian",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Legend
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendDot(color = EmeraldPrimary, label = "Omzet Penjualan")
                LegendDot(color = GoldBright, label = "Laba Kotor")
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (dailyTrend.isNotEmpty()) {
                val selectedPoint = dailyTrend.getOrElse(selectedBarIndex) { dailyTrend.last() }
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${selectedPoint.dayLabel} (${selectedPoint.dateLabel})",
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "${selectedPoint.txCount} Transaksi Selesai",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Omzet: ${FormatUtils.formatRupiah(selectedPoint.revenue)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = EmeraldPrimary
                            )
                            Text(
                                text = "Laba: ${FormatUtils.formatRupiah(selectedPoint.grossProfit)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = GoldAccent
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                val maxRev = dailyTrend.maxOfOrNull { it.revenue }?.coerceAtLeast(100_000L) ?: 100_000L

                // Custom Canvas Dual Bar Chart
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                ) {
                    val count = dailyTrend.size
                    val slotWidth = size.width / count
                    val barWidth = (slotWidth * 0.28f).coerceAtMost(24f)

                    // Horizontal subtle grid lines
                    for (i in 1..3) {
                        val y = size.height * (1f - i / 3f)
                        drawLine(
                            color = Color(0xFFE2E8F0),
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1.5f
                        )
                    }

                    dailyTrend.forEachIndexed { idx, point ->
                        val centerX = idx * slotWidth + slotWidth / 2f
                        val revRatio = (point.revenue.toFloat() / maxRev.toFloat()).coerceIn(0.04f, 1f)
                        val profitRatio = (point.grossProfit.toFloat() / maxRev.toFloat()).coerceIn(0.02f, 1f)

                        val revHeight = size.height * revRatio
                        val profitHeight = size.height * profitRatio

                        // Highlight background if selected
                        if (idx == selectedBarIndex) {
                            drawRoundRect(
                                color = EmeraldSoft.copy(alpha = 0.45f),
                                topLeft = Offset(idx * slotWidth + 4f, 0f),
                                size = Size(slotWidth - 8f, size.height),
                                cornerRadius = CornerRadius(12f, 12f)
                            )
                        }

                        // Revenue bar
                        drawRoundRect(
                            color = EmeraldPrimary,
                            topLeft = Offset(centerX - barWidth - 2f, size.height - revHeight),
                            size = Size(barWidth, revHeight),
                            cornerRadius = CornerRadius(6f, 6f)
                        )

                        // Profit bar
                        drawRoundRect(
                            color = GoldBright,
                            topLeft = Offset(centerX + 2f, size.height - profitHeight),
                            size = Size(barWidth, profitHeight),
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Day Selector Labels Underneath
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    dailyTrend.forEachIndexed { idx, point ->
                        val isSelected = idx == selectedBarIndex
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { selectedBarIndex = idx }
                                .padding(vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = point.dayLabel.take(3),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                ),
                                color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = point.dateLabel.substringBefore(" "),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun CategoryAndPaymentBreakdownCard(
    categoryStats: List<CategoryStat>,
    paymentStats: List<PaymentMethodStat>
) {
    var showPaymentTab by remember { mutableStateOf(false) }
    val chartColors = listOf(
        EmeraldPrimary,
        GoldBright,
        InfoBlue,
        PurpleAccent,
        DangerRed
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (showPaymentTab) Icons.Default.Payments else Icons.Default.PieChart,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (showPaymentTab) "Metode Pembayaran" else "Proporsi Kategori",
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = !showPaymentTab,
                        onClick = { showPaymentTab = false },
                        label = { Text("Kategori") }
                    )
                    FilterChip(
                        selected = showPaymentTab,
                        onClick = { showPaymentTab = true },
                        label = { Text("Metode Bayar") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Donut Chart via Canvas
                Box(
                    modifier = Modifier.size(120.dp),
                    contentAlignment = Alignment.Center
                ) {
                    val slices = if (showPaymentTab) {
                        paymentStats.map { it.percentage }
                    } else {
                        categoryStats.map { it.percentage }
                    }

                    Canvas(modifier = Modifier.size(110.dp)) {
                        val strokeWidth = 24f
                        if (slices.isEmpty()) {
                            drawArc(
                                color = Color(0xFFE2E8F0),
                                startAngle = 0f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                        } else {
                            var startAngle = -90f
                            slices.forEachIndexed { index, pct ->
                                val sweep = (pct / 100f) * 360f
                                drawArc(
                                    color = chartColors[index % chartColors.size],
                                    startAngle = startAngle,
                                    sweepAngle = (sweep - 2f).coerceAtLeast(2f),
                                    useCenter = false,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                )
                                startAngle += sweep
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (showPaymentTab) "${paymentStats.size}" else "${categoryStats.size}",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = if (showPaymentTab) "Metode" else "Kategori",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Breakdown List
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!showPaymentTab) {
                        categoryStats.take(5).forEachIndexed { idx, stat ->
                            BreakdownLegendItem(
                                color = chartColors[idx % chartColors.size],
                                title = stat.category,
                                subtitle = "${stat.itemsSold} terjual • ${FormatUtils.formatCompactRupiah(stat.revenue)}",
                                percentage = stat.percentage
                            )
                        }
                    } else {
                        paymentStats.forEachIndexed { idx, stat ->
                            BreakdownLegendItem(
                                color = chartColors[idx % chartColors.size],
                                title = stat.method,
                                subtitle = "${stat.count} nota • ${FormatUtils.formatCompactRupiah(stat.totalAmount)}",
                                percentage = stat.percentage
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BreakdownLegendItem(
    color: Color,
    title: String,
    subtitle: String,
    percentage: Float
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(color, CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Text(
            text = "${String.format("%.0f", percentage)}%",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun TopProductsLeaderboardCard(topProducts: List<TopProductStat>) {
    val maxSold = topProducts.maxOfOrNull { it.quantitySold }?.coerceAtLeast(1) ?: 1

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = GoldAccent
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Produk Terlaris (Top Menu)",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Kontribusi penjualan & laba tertinggi",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            topProducts.forEachIndexed { index, item ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                color = if (index == 0) GoldSoft else EmeraldSoft,
                                shape = CircleShape,
                                modifier = Modifier.size(28.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "#${index + 1}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (index == 0) GoldAccent else EmeraldPrimary
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = item.productName,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${item.quantitySold} terjual • Laba ${FormatUtils.formatCompactRupiah(item.profit)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Text(
                            text = FormatUtils.formatRupiah(item.revenue),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = EmeraldPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { (item.quantitySold.toFloat() / maxSold.toFloat()).coerceIn(0.08f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(50)),
                        color = if (index == 0) GoldBright else EmeraldPrimary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun LowStockAlertCard(
    lowStockProducts: List<ProductEntity>,
    onQuickRestock: (Long, Int) -> Unit,
    onOpenInventory: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = DangerSoft.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WarningAmber,
                        contentDescription = "Stok Menipis",
                        tint = DangerRed
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Peringatan Stok Menipis (${lowStockProducts.size} SKU)",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color(0xFF7F1D1D)
                        )
                        Text(
                            text = "Segera lakukan restock agar kasir tidak kehabisan",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF991B1B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            lowStockProducts.forEach { product ->
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = product.name,
                                style = MaterialTheme.typography.titleSmall,
                                color = Color(0xFF0F172A)
                            )
                            Text(
                                text = "Sisa Stok: ${product.stock} ${product.unit} (Min: ${product.minStockAlert})",
                                style = MaterialTheme.typography.labelSmall,
                                color = DangerRed
                            )
                        }

                        Button(
                            onClick = { onQuickRestock(product.id, 15) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("quick_restock_${product.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddBusiness,
                                contentDescription = "Restock",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "+15 Stok",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecentTransactionsCard(
    transactions: List<TransactionWithItems>,
    onSelectTransaction: (TransactionWithItems) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Transaksi Kasir Terbaru",
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = "Ketuk transaksi untuk melihat atau mencetak ulang struk",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            transactions.forEachIndexed { idx, txWithItems ->
                val tx = txWithItems.transaction
                val isVoid = tx.status == "VOID"
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectTransaction(txWithItems) }
                        .padding(vertical = 10.dp, horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    if (isVoid) DangerSoft else EmeraldSoft,
                                    RoundedCornerShape(12.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddShoppingCart,
                                contentDescription = null,
                                tint = if (isVoid) DangerRed else EmeraldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "${tx.invoiceNumber} • ${tx.customerName}",
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "${FormatUtils.formatDateTime(tx.timestamp)} • ${tx.paymentMethod}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = FormatUtils.formatRupiah(tx.totalAmount),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (isVoid) DangerRed else EmeraldPrimary
                        )
                        Text(
                            text = if (isVoid) "VOID" else "${txWithItems.items.sumOf { it.quantity }} item",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isVoid) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (idx < transactions.lastIndex) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                }
            }
        }
    }
}
