package com.example.ui.components

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.StoreProfileEntity
import com.example.data.TransactionWithItems
import com.example.ui.FormatUtils
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DangerSoft
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.JetBrainsMono
import kotlinx.coroutines.launch

@Composable
fun DashedReceiptDivider(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(2.dp)
            .padding(vertical = 1.dp)
    ) {
        drawLine(
            color = Color(0xFF94A3B8),
            start = Offset(0f, 0f),
            end = Offset(size.width, 0f),
            strokeWidth = 2f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)
        )
    }
}

@Composable
fun DigitalReceiptDialog(
    txWithItems: TransactionWithItems,
    storeProfile: StoreProfileEntity,
    onDismiss: () -> Unit,
    onOpenPrinterSettings: (() -> Unit)? = null,
    onVoidTransaction: ((TransactionWithItems) -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tx = txWithItems.transaction
    val isVoid = tx.status == "VOID"
    var printStatusMessage by remember { mutableStateOf<String?>(null) }
    var isPrintError by remember { mutableStateOf(false) }

    val printerConfig = remember { EscPosPrinterHelper.loadConfig(context) }

    LaunchedEffect(tx.id) {
        if (printerConfig.autoPrintOnCheckout && printerConfig.selectedBtAddress.isNotBlank() && !isVoid) {
            val bytes = EscPosPrinterHelper.buildEscPosReceiptBytes(txWithItems, storeProfile, printerConfig)
            val res = EscPosPrinterHelper.sendEscPosToBluetooth(context, printerConfig.selectedBtAddress, bytes)
            res.onSuccess {
                printStatusMessage = "Auto-Print: $it"
                isPrintError = false
            }.onFailure { err ->
                printStatusMessage = "Auto-Print gagal: ${err.localizedMessage ?: "Cek koneksi printer"}"
                isPrintError = true
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("digital_receipt_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF9F5)),
            elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Badge
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .background(
                            if (isVoid) Color(0xFFFEE2E2) else EmeraldSoft,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isVoid) Icons.Outlined.Cancel else Icons.Default.CheckCircle,
                        contentDescription = "Status Transaksi",
                        tint = if (isVoid) DangerRed else EmeraldPrimary,
                        modifier = Modifier.size(30.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = storeProfile.storeName,
                    style = MaterialTheme.typography.titleLarge,
                    color = Color(0xFF0F172A),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = storeProfile.storeAddress,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF475569),
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Telp: ${storeProfile.storePhone}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF475569),
                    textAlign = TextAlign.Center
                )

                if (isVoid) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        color = Color(0xFFFEE2E2),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "TRANSAKSI DIBATALKAN (VOID)",
                            style = MaterialTheme.typography.labelMedium,
                            color = DangerRed,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                DashedReceiptDivider()
                Spacer(modifier = Modifier.height(10.dp))

                // Invoice Metadata
                ReceiptMetaRow("No. Struk", tx.invoiceNumber)
                ReceiptMetaRow("Tanggal", FormatUtils.formatDateTime(tx.timestamp))
                ReceiptMetaRow("Kasir", tx.cashierName)
                ReceiptMetaRow("Pelanggan", tx.customerName)
                ReceiptMetaRow("Pembayaran", tx.paymentMethod)

                Spacer(modifier = Modifier.height(10.dp))
                DashedReceiptDivider()
                Spacer(modifier = Modifier.height(10.dp))

                // Line Items
                txWithItems.items.forEach { item ->
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = item.productName,
                            style = MaterialTheme.typography.titleSmall,
                            color = Color(0xFF0F172A)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${item.quantity} x ${FormatUtils.formatRupiah(item.sellPrice)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color(0xFF475569)
                            )
                            Text(
                                text = FormatUtils.formatRupiah(item.subtotal),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF0F172A)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                DashedReceiptDivider()
                Spacer(modifier = Modifier.height(10.dp))

                // Totals
                ReceiptMetaRow("Subtotal", FormatUtils.formatRupiah(tx.subtotal))
                if (tx.discountAmount > 0) {
                    ReceiptMetaRow("Diskon Promo", "- ${FormatUtils.formatRupiah(tx.discountAmount)}")
                }
                if (tx.taxAmount > 0) {
                    ReceiptMetaRow("PPN / Pajak", FormatUtils.formatRupiah(tx.taxAmount))
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TOTAL BAYAR",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = FormatUtils.formatRupiah(tx.totalAmount),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = JetBrainsMono,
                            fontWeight = FontWeight.Bold
                        ),
                        color = EmeraldPrimary
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                ReceiptMetaRow("Dibayar (${tx.paymentMethod})", FormatUtils.formatRupiah(tx.amountPaid))
                ReceiptMetaRow("Kembalian", FormatUtils.formatRupiah(tx.changeAmount))

                if (tx.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    ReceiptMetaRow("Catatan", tx.notes)
                }

                Spacer(modifier = Modifier.height(12.dp))
                DashedReceiptDivider()
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = storeProfile.receiptFooter,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B),
                    textAlign = TextAlign.Center
                )

                if (printStatusMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = if (isPrintError) DangerSoft else EmeraldSoft,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = printStatusMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isPrintError) DangerRed else EmeraldPrimary,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Printer Action Buttons Row 1: Bluetooth Thermal & System/PDF Print
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val latestCfg = EscPosPrinterHelper.loadConfig(context)
                            if (latestCfg.selectedBtAddress.isBlank()) {
                                if (onOpenPrinterSettings != null) {
                                    onOpenPrinterSettings()
                                } else {
                                    printStatusMessage = "Pilih printer Bluetooth di Pengaturan Printer terlebih dahulu."
                                    isPrintError = true
                                }
                            } else {
                                scope.launch {
                                    printStatusMessage = "Mengirim ke printer ${latestCfg.selectedBtName} (${latestCfg.paperWidthMm}mm)..."
                                    isPrintError = false
                                    val bytes = EscPosPrinterHelper.buildEscPosReceiptBytes(
                                        txWithItems,
                                        storeProfile,
                                        latestCfg
                                    )
                                    val res = EscPosPrinterHelper.sendEscPosToBluetooth(
                                        context,
                                        latestCfg.selectedBtAddress,
                                        bytes
                                    )
                                    res.onSuccess { msg ->
                                        printStatusMessage = msg
                                        isPrintError = false
                                    }.onFailure { err ->
                                        printStatusMessage = "Gagal cetak Bluetooth: ${err.localizedMessage ?: "Pastikan printer menyala"}"
                                        isPrintError = true
                                    }
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("print_bluetooth_receipt_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bluetooth,
                            contentDescription = "Cetak Bluetooth",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Cetak Thermal")
                    }

                    OutlinedButton(
                        onClick = {
                            val latestCfg = EscPosPrinterHelper.loadConfig(context)
                            EscPosPrinterHelper.printViaAndroidPrintManager(
                                context = context,
                                txWithItems = txWithItems,
                                storeProfile = storeProfile,
                                paperWidthMm = latestCfg.paperWidthMm
                            )
                            printStatusMessage = "Membuka layanan Cetak Sistem / PDF (${latestCfg.paperWidthMm}mm)..."
                            isPrintError = false
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("print_receipt_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Print,
                            contentDescription = "Cetak Sistem / PDF",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Cetak / PDF")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Row 2: Share & Printer Settings
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val receiptText = buildReceiptPlainText(txWithItems, storeProfile)
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Struk ${tx.invoiceNumber} - ${storeProfile.storeName}")
                                putExtra(Intent.EXTRA_TEXT, receiptText)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Bagikan Struk Digital"))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("share_receipt_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Bagikan Struk",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Bagikan")
                    }

                    if (onOpenPrinterSettings != null) {
                        OutlinedButton(
                            onClick = onOpenPrinterSettings,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("receipt_printer_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Setelan Printer",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Set Printer")
                        }
                    }
                }

                if (onVoidTransaction != null && !isVoid) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            onVoidTransaction(txWithItems)
                            onDismiss()
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("void_transaction_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Cancel,
                            contentDescription = "Batalkan Transaksi",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Batalkan Transaksi (Void & Kembalikan Stok)")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("close_receipt_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A))
                ) {
                    Text("Selesai & Tutup")
                }
            }
        }
    }
}

@Composable
private fun ReceiptMetaRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF64748B)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = Color(0xFF0F172A)
        )
    }
}

private fun buildReceiptPlainText(
    txWithItems: TransactionWithItems,
    storeProfile: StoreProfileEntity
): String {
    val tx = txWithItems.transaction
    val sb = StringBuilder()
    sb.appendLine("================================")
    sb.appendLine(storeProfile.storeName.uppercase())
    sb.appendLine(storeProfile.storeAddress)
    sb.appendLine("Telp: ${storeProfile.storePhone}")
    sb.appendLine("================================")
    sb.appendLine("No Struk : ${tx.invoiceNumber}")
    sb.appendLine("Tanggal  : ${FormatUtils.formatDateTime(tx.timestamp)}")
    sb.appendLine("Kasir    : ${tx.cashierName}")
    sb.appendLine("Pelanggan: ${tx.customerName}")
    sb.appendLine("--------------------------------")
    txWithItems.items.forEach { item ->
        sb.appendLine(item.productName)
        sb.appendLine("  ${item.quantity} x ${FormatUtils.formatRupiah(item.sellPrice)} = ${FormatUtils.formatRupiah(item.subtotal)}")
    }
    sb.appendLine("--------------------------------")
    sb.appendLine("Subtotal : ${FormatUtils.formatRupiah(tx.subtotal)}")
    if (tx.discountAmount > 0) {
        sb.appendLine("Diskon   : -${FormatUtils.formatRupiah(tx.discountAmount)}")
    }
    if (tx.taxAmount > 0) {
        sb.appendLine("Pajak    : ${FormatUtils.formatRupiah(tx.taxAmount)}")
    }
    sb.appendLine("TOTAL    : ${FormatUtils.formatRupiah(tx.totalAmount)}")
    sb.appendLine("Bayar (${tx.paymentMethod}): ${FormatUtils.formatRupiah(tx.amountPaid)}")
    sb.appendLine("Kembali  : ${FormatUtils.formatRupiah(tx.changeAmount)}")
    sb.appendLine("================================")
    sb.appendLine(storeProfile.receiptFooter)
    return sb.toString()
}

@Composable
fun StoreSettingsDialog(
    currentProfile: StoreProfileEntity,
    onDismiss: () -> Unit,
    onSave: (StoreProfileEntity) -> Unit
) {
    var storeName by remember { mutableStateOf(currentProfile.storeName) }
    var storeAddress by remember { mutableStateOf(currentProfile.storeAddress) }
    var storePhone by remember { mutableStateOf(currentProfile.storePhone) }
    var cashierName by remember { mutableStateOf(currentProfile.cashierName) }
    var taxPercentText by remember { mutableStateOf(currentProfile.taxPercent.toString()) }
    var dailyTargetText by remember { mutableStateOf(currentProfile.dailyTarget.toString()) }
    var receiptFooter by remember { mutableStateOf(currentProfile.receiptFooter) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("store_settings_dialog"),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = "Pengaturan Toko",
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Pengaturan Toko & Kasir",
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                OutlinedTextField(
                    value = storeName,
                    onValueChange = { storeName = it },
                    label = { Text("Nama Toko / Usaha") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = storeAddress,
                    onValueChange = { storeAddress = it },
                    label = { Text("Alamat Toko (Tampil di Struk)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = storePhone,
                        onValueChange = { storePhone = it },
                        label = { Text("Nomor Telepon") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = taxPercentText,
                        onValueChange = { taxPercentText = it.filter { c -> c.isDigit() } },
                        label = { Text("PPN (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(0.7f),
                        singleLine = true
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = cashierName,
                    onValueChange = { cashierName = it },
                    label = { Text("Nama Kasir / Shift Aktif") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = dailyTargetText,
                    onValueChange = { dailyTargetText = it.filter { c -> c.isDigit() } },
                    label = { Text("Target Omzet Harian (Rp)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = receiptFooter,
                    onValueChange = { receiptFooter = it },
                    label = { Text("Catatan Kaki Struk (Footer)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Batal")
                    }
                    Button(
                        onClick = {
                            onSave(
                                currentProfile.copy(
                                    storeName = storeName.ifBlank { "KasirPro Store" },
                                    storeAddress = storeAddress,
                                    storePhone = storePhone,
                                    cashierName = cashierName.ifBlank { "Kasir Utama" },
                                    taxPercent = (taxPercentText.toIntOrNull() ?: 10).coerceIn(0, 100),
                                    dailyTarget = (dailyTargetText.toLongOrNull() ?: 3500000L).coerceAtLeast(100000L),
                                    receiptFooter = receiptFooter
                                )
                            )
                            onDismiss()
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("save_store_profile_button")
                    ) {
                        Text("Simpan")
                    }
                }
            }
        }
    }
}
