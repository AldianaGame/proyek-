package com.example

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.automirrored.outlined.ReceiptLong
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.KasirDatabase
import com.example.data.KasirRepository
import com.example.data.TransactionWithItems
import com.example.ui.KasirViewModel
import com.example.ui.components.CsvExportDialog
import com.example.ui.components.CsvReportType
import com.example.ui.components.DigitalReceiptDialog
import com.example.ui.components.PrinterSettingsDialog
import com.example.ui.components.StoreSettingsDialog
import com.example.ui.screens.ActiveSession
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.PosCashierScreen
import com.example.ui.screens.TransactionsAndCashflowScreen
import com.example.ui.screens.UserRole
import com.example.ui.theme.DangerRed
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldSoft
import com.example.ui.theme.MyApplicationTheme

enum class KasirTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    DASHBOARD("dashboard", "Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
    POS_CASHIER("cashier", "Kasir POS", Icons.Filled.PointOfSale, Icons.Outlined.PointOfSale),
    INVENTORY("inventory", "Inventori", Icons.Filled.Inventory2, Icons.Outlined.Inventory2),
    TRANSACTIONS("transactions", "Laporan & Kas", Icons.AutoMirrored.Filled.ReceiptLong, Icons.AutoMirrored.Outlined.ReceiptLong)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            val prefs = remember {
                context.getSharedPreferences("kasir_ui_prefs", Context.MODE_PRIVATE)
            }
            var isDarkMode by rememberSaveable {
                mutableStateOf(prefs.getBoolean("dark_mode", false))
            }

            MyApplicationTheme(darkTheme = isDarkMode) {
                KasirProApp(
                    isDarkMode = isDarkMode,
                    onToggleDarkMode = {
                        val next = !isDarkMode
                        isDarkMode = next
                        prefs.edit().putBoolean("dark_mode", next).apply()
                    }
                )
            }
        }
    }
}

@Composable
fun KasirProApp(
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit
) {
    val context = LocalContext.current
    val repository = remember {
        val db = KasirDatabase.getInstance(context)
        KasirRepository(db.kasirDao())
    }
    val viewModel: KasirViewModel = viewModel(
        factory = KasirViewModel.provideFactory(repository)
    )

    val products by viewModel.products.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val expenses by viewModel.expenses.collectAsStateWithLifecycle()
    val storeProfile by viewModel.storeProfile.collectAsStateWithLifecycle()
    val analytics by viewModel.dashboardAnalytics.collectAsStateWithLifecycle()
    val cart by viewModel.cart.collectAsStateWithLifecycle()
    val discountAmount by viewModel.discountAmount.collectAsStateWithLifecycle()
    val taxEnabled by viewModel.taxEnabled.collectAsStateWithLifecycle()
    val lastCompletedSale by viewModel.lastCompletedSale.collectAsStateWithLifecycle()

    var activeRoleName by rememberSaveable { mutableStateOf<String?>(null) }
    var activeDisplayName by rememberSaveable { mutableStateOf("") }
    val activeSession = remember(activeRoleName, activeDisplayName) {
        activeRoleName?.let { roleStr ->
            val role = UserRole.entries.find { it.name == roleStr } ?: UserRole.CASHIER
            ActiveSession(role = role, displayName = activeDisplayName)
        }
    }
    var currentTab by rememberSaveable { mutableStateOf(KasirTab.DASHBOARD) }
    var selectedReceiptTx by remember { mutableStateOf<TransactionWithItems?>(null) }
    var showStoreSettings by remember { mutableStateOf(false) }
    var showPrinterSettings by remember { mutableStateOf(false) }
    var csvExportType by remember { mutableStateOf<CsvReportType?>(null) }

    // Show Login Screen if no session is active
    val session = activeSession
    if (session == null) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                LoginScreen(
                    storeProfile = storeProfile,
                    isDarkMode = isDarkMode,
                    onToggleDarkMode = onToggleDarkMode,
                    onLoginSuccess = { loggedInSession ->
                        activeRoleName = loggedInSession.role.name
                        activeDisplayName = loggedInSession.displayName
                        if (loggedInSession.role == UserRole.CASHIER) {
                            viewModel.updateStoreProfile(
                                storeProfile.copy(cashierName = loggedInSession.displayName)
                            )
                            currentTab = KasirTab.POS_CASHIER
                        } else {
                            currentTab = KasirTab.DASHBOARD
                        }
                    }
                )
            }
        }
        return
    }

    val isOwner = session.role == UserRole.OWNER
    val visibleTabs = remember(isOwner) {
        if (isOwner) {
            KasirTab.entries
        } else {
            listOf(KasirTab.POS_CASHIER, KasirTab.INVENTORY, KasirTab.TRANSACTIONS)
        }
    }

    val homeTab = if (isOwner) KasirTab.DASHBOARD else KasirTab.POS_CASHIER
    if (currentTab != homeTab) {
        BackHandler {
            currentTab = homeTab
        }
    }

    val totalCartQty = cart.sumOf { it.quantity }
    val lowStockCount = analytics.lowStockProducts.size

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            ActiveSessionTopBar(
                session = session,
                isDarkMode = isDarkMode,
                onToggleDarkMode = onToggleDarkMode,
                onOpenCsvExport = { csvExportType = CsvReportType.TRANSACTIONS },
                onSwitchOrLogout = {
                    activeRoleName = null
                    activeDisplayName = ""
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                visibleTabs.forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (tab == KasirTab.POS_CASHIER && totalCartQty > 0) {
                                        Badge(
                                            containerColor = GoldBright,
                                            contentColor = Color(0xFF0F172A)
                                        ) {
                                            Text("$totalCartQty")
                                        }
                                    } else if (tab == KasirTab.INVENTORY && lowStockCount > 0) {
                                        Badge(
                                            containerColor = DangerRed,
                                            contentColor = Color.White
                                        ) {
                                            Text("$lowStockCount")
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = tab.label
                                )
                            }
                        },
                        label = {
                            Text(
                                text = if (!isOwner && tab == KasirTab.TRANSACTIONS) "Riwayat Nota" else tab.label
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = EmeraldPrimary,
                            selectedTextColor = EmeraldPrimary,
                            indicatorColor = EmeraldSoft
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.route}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                KasirTab.DASHBOARD -> {
                    DashboardScreen(
                        analytics = analytics,
                        storeProfile = storeProfile,
                        recentTransactions = transactions,
                        onSelectPeriod = viewModel::selectPeriod,
                        onOpenCashier = { currentTab = KasirTab.POS_CASHIER },
                        onOpenInventory = { currentTab = KasirTab.INVENTORY },
                        onOpenSettings = { showStoreSettings = true },
                        onExportCsv = { csvExportType = CsvReportType.PROFIT_LOSS },
                        onQuickRestock = viewModel::adjustProductStock,
                        onSelectTransaction = { selectedReceiptTx = it }
                    )
                }

                KasirTab.POS_CASHIER -> {
                    PosCashierScreen(
                        products = products,
                        cart = cart,
                        discountAmount = discountAmount,
                        taxEnabled = taxEnabled,
                        storeProfile = storeProfile,
                        onAddToCart = viewModel::addToCart,
                        onUpdateCartQty = viewModel::updateCartQuantity,
                        onClearCart = viewModel::clearCart,
                        onSetDiscount = viewModel::setDiscountAmount,
                        onSetTaxEnabled = viewModel::setTaxEnabled,
                        onOpenPrinterSettings = { showPrinterSettings = true },
                        onCheckout = viewModel::processCheckout
                    )
                }

                KasirTab.INVENTORY -> {
                    InventoryScreen(
                        products = products,
                        analytics = analytics,
                        onSaveProduct = viewModel::saveProduct,
                        onDeleteProduct = viewModel::deleteProduct,
                        onAdjustStock = viewModel::adjustProductStock,
                        onExportCsv = { csvExportType = CsvReportType.INVENTORY }
                    )
                }

                KasirTab.TRANSACTIONS -> {
                    TransactionsAndCashflowScreen(
                        transactions = transactions,
                        expenses = expenses,
                        analytics = analytics,
                        onSelectTransaction = { selectedReceiptTx = it },
                        onAddExpense = viewModel::addExpense,
                        onDeleteExpense = viewModel::deleteExpense,
                        onExportCsv = { csvExportType = CsvReportType.TRANSACTIONS }
                    )
                }
            }
        }
    }

    // Show Digital Receipt Modal right after POS Checkout
    val activeReceipt = lastCompletedSale ?: selectedReceiptTx
    if (activeReceipt != null) {
        DigitalReceiptDialog(
            txWithItems = activeReceipt,
            storeProfile = storeProfile,
            onDismiss = {
                viewModel.dismissReceiptModal()
                selectedReceiptTx = null
            },
            onOpenPrinterSettings = { showPrinterSettings = true },
            onVoidTransaction = if (isOwner) {
                { txToVoid -> viewModel.voidTransaction(txToVoid) }
            } else null
        )
    }

    if (showStoreSettings) {
        StoreSettingsDialog(
            currentProfile = storeProfile,
            onDismiss = { showStoreSettings = false },
            onSave = viewModel::updateStoreProfile
        )
    }

    if (showPrinterSettings) {
        PrinterSettingsDialog(
            storeProfile = storeProfile,
            onDismiss = { showPrinterSettings = false }
        )
    }

    if (csvExportType != null) {
        CsvExportDialog(
            initialType = csvExportType!!,
            transactions = transactions,
            products = products,
            expenses = expenses,
            analytics = analytics,
            storeProfile = storeProfile,
            onDismiss = { csvExportType = null }
        )
    }
}

@Composable
private fun ActiveSessionTopBar(
    session: ActiveSession,
    isDarkMode: Boolean,
    onToggleDarkMode: () -> Unit,
    onOpenCsvExport: () -> Unit,
    onSwitchOrLogout: () -> Unit
) {
    val isOwner = session.role == UserRole.OWNER
    Surface(
        color = if (isOwner) Color(0xFF0F172A) else EmeraldDark,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    color = if (isOwner) GoldBright else EmeraldSoft,
                    shape = CircleShape,
                    modifier = Modifier.size(30.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isOwner) Icons.Default.AdminPanelSettings else Icons.Default.Badge,
                            contentDescription = null,
                            tint = if (isOwner) Color(0xFF0F172A) else EmeraldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Surface(
                        color = if (isOwner) GoldSoft.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = session.role.badgeText,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (isOwner) GoldBright else EmeraldSoft,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                        )
                    }
                    Text(
                        text = session.displayName,
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // CSV Export Quick Icon Button
                IconButton(
                    onClick = onOpenCsvExport,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("top_bar_csv_export_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.TableView,
                        contentDescription = "Ekspor CSV",
                        tint = GoldBright,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Dark Mode Toggle Button
                IconButton(
                    onClick = onToggleDarkMode,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("top_bar_dark_mode_toggle")
                ) {
                    Icon(
                        imageVector = if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                        contentDescription = if (isDarkMode) "Mode Terang" else "Mode Gelap",
                        tint = if (isDarkMode) GoldBright else EmeraldSoft,
                        modifier = Modifier.size(20.dp)
                    )
                }

                OutlinedButton(
                    onClick = onSwitchOrLogout,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("switch_role_logout_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "Ganti Akun / Keluar",
                        tint = Color.White,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Keluar",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                }
            }
        }
    }
}
