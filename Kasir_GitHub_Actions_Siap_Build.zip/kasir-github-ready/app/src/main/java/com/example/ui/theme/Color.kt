package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Emerald & Gold Pro POS Palette
val EmeraldPrimary = Color(0xFF065F46)
val EmeraldDark = Color(0xFF064E3B)
val EmeraldVibrant = Color(0xFF10B981)
val EmeraldSoft = Color(0xFFD1FAE5)

val GoldAccent = Color(0xFFD97706)
val GoldBright = Color(0xFFF59E0B)
val GoldSoft = Color(0xFFFEF3C7)

val SlateDark = Color(0xFF0F172A)
val SlateSurface = Color(0xFF1E293B)
val SlateMuted = Color(0xFF64748B)
val BackgroundLight = Color(0xFFF4F7F6)
val SurfaceWhite = Color(0xFFFFFFFF)

val DangerRed = Color(0xFFDC2626)
val DangerSoft = Color(0xFFFEE2E2)
val InfoBlue = Color(0xFF2563EB)
val InfoSoft = Color(0xFFDBEAFE)
val PurpleAccent = Color(0xFF7C3AED)
val PurpleSoft = Color(0xFFEDE9FE)
