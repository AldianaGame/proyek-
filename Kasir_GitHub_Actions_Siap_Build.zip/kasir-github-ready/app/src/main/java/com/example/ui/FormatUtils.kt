package com.example.ui

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object FormatUtils {
    private val indonesiaLocale = Locale("in", "ID")

    fun formatRupiah(amount: Long): String {
        val formatter = NumberFormat.getNumberInstance(indonesiaLocale)
        return "Rp ${formatter.format(amount)}"
    }

    fun formatCompactRupiah(amount: Long): String {
        val absAmount = kotlin.math.abs(amount)
        val sign = if (amount < 0) "-" else ""
        return when {
            absAmount >= 1_000_000_000L -> String.format(indonesiaLocale, "%sRp %.1f M", sign, absAmount / 1_000_000_000.0)
            absAmount >= 1_000_000L -> String.format(indonesiaLocale, "%sRp %.2f Jt", sign, absAmount / 1_000_000.0)
            absAmount >= 1_000L -> String.format(indonesiaLocale, "%sRp %d Rb", sign, absAmount / 1_000L)
            else -> "${sign}Rp $absAmount"
        }
    }

    fun formatDateTime(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy • HH:mm", indonesiaLocale)
        return sdf.format(Date(timestamp))
    }

    fun formatShortDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM", indonesiaLocale)
        return sdf.format(Date(timestamp))
    }

    fun formatDayLabel(timestamp: Long): String {
        val sdf = SimpleDateFormat("EEE", indonesiaLocale)
        return sdf.format(Date(timestamp))
    }

    fun formatTimeOnly(timestamp: Long): String {
        val sdf = SimpleDateFormat("HH:mm", indonesiaLocale)
        return sdf.format(Date(timestamp))
    }

    fun getStartOfTodayMs(nowMs: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance()
        cal.timeInMillis = nowMs
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
