package com.example.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sku: String,
    val name: String,
    val category: String,
    val buyPrice: Long,   // Harga Modal (HPP) dalam Rupiah
    val sellPrice: Long,  // Harga Jual dalam Rupiah
    val stock: Int,
    val minStockAlert: Int = 5,
    val unit: String = "Pcs",
    val colorHex: String = "#065F46",
    val isActive: Boolean = true
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNumber: String,
    val timestamp: Long = System.currentTimeMillis(),
    val customerName: String = "Pelanggan Umum",
    val subtotal: Long,
    val discountAmount: Long = 0,
    val taxAmount: Long = 0,
    val totalAmount: Long,
    val totalCost: Long, // Total HPP untuk kalkulasi Laba Kotor akurat
    val paymentMethod: String, // "TUNAI", "QRIS", "DEBIT", "TRANSFER"
    val amountPaid: Long,
    val changeAmount: Long,
    val cashierName: String = "Admin Kasir",
    val notes: String = "",
    val status: String = "COMPLETED" // "COMPLETED" or "VOID"
)

@Entity(
    tableName = "transaction_items",
    foreignKeys = [
        ForeignKey(
            entity = TransactionEntity::class,
            parentColumns = ["id"],
            childColumns = ["transactionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("transactionId")]
)
data class TransactionItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: Long,
    val productId: Long,
    val productName: String,
    val sku: String,
    val category: String,
    val buyPrice: Long,
    val sellPrice: Long,
    val quantity: Int,
    val subtotal: Long
)

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String, // "Bahan Baku", "Operasional", "Listrik & Air", "Gaji", "Lainnya"
    val amount: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "store_profile")
data class StoreProfileEntity(
    @PrimaryKey val id: Int = 1,
    val storeName: String = "Kopi & Roastery Nusantara",
    val storeAddress: String = "Jl. Sudirman No. 88, Jakarta Selatan",
    val storePhone: String = "0812-8899-7766",
    val cashierName: String = "Nadia Putri (Shift Pagi)",
    val taxPercent: Int = 10,
    val receiptFooter: String = "Terima kasih telah berbelanja! Simpan struk ini sebagai bukti pembayaran sah.",
    val dailyTarget: Long = 3500000L
)
